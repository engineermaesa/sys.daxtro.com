<?php return array (
  2 => 'broadcasting',
  4 => 'concurrency',
  5 => 'cors',
  8 => 'hashing',
  14 => 'view',
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'frontend_url' => 'http://localhost:3000',
    'asset_url' => NULL,
    'timezone' => 'Asia/Jakarta',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'cipher' => 'AES-256-CBC',
    'key' => 'base64:D8GJ/kBR2d11jcHiI36Tw5HKuVK/lqapX9LuTdviWQY=',
    'previous_keys' => 
    array (
    ),
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Concurrency\\ConcurrencyServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      14 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      15 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      16 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      17 => 'Illuminate\\Queue\\QueueServiceProvider',
      18 => 'Illuminate\\Redis\\RedisServiceProvider',
      19 => 'Illuminate\\Session\\SessionServiceProvider',
      20 => 'Illuminate\\Translation\\TranslationServiceProvider',
      21 => 'Illuminate\\Validation\\ValidationServiceProvider',
      22 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
      24 => 'Webklex\\PDFMerger\\Providers\\PDFMergerServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Concurrency' => 'Illuminate\\Support\\Facades\\Concurrency',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Context' => 'Illuminate\\Support\\Facades\\Context',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schedule' => 'Illuminate\\Support\\Facades\\Schedule',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Uri' => 'Illuminate\\Support\\Uri',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
    'locked' => false,
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'cache',
        'lock_connection' => NULL,
        'lock_table' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\framework/cache/data',
        'lock_path' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'laravel_cache_',
  ),
  'cities' => 
  array (
    0 => 'Tidak ada dalam list',
    1 => 'Kabupaten Aceh Barat',
    2 => 'Kabupaten Aceh Barat Daya',
    3 => 'Kabupaten Aceh Besar',
    4 => 'Kabupaten Aceh Jaya',
    5 => 'Kabupaten Aceh Selatan',
    6 => 'Kabupaten Aceh Singkil',
    7 => 'Kabupaten Aceh Tamiang',
    8 => 'Kabupaten Aceh Tengah',
    9 => 'Kabupaten Aceh Tenggara',
    10 => 'Kabupaten Aceh Timur',
    11 => 'Kabupaten Aceh Utara',
    12 => 'Kabupaten Administrasi Kepulauan Seribu',
    13 => 'Kabupaten Agam',
    14 => 'Kabupaten Alor',
    15 => 'Kabupaten Asahan',
    16 => 'Kabupaten Asmat',
    17 => 'Kabupaten Badung',
    18 => 'Kabupaten Balangan',
    19 => 'Kabupaten Bandung',
    20 => 'Kabupaten Bandung Barat',
    21 => 'Kabupaten Banggai',
    22 => 'Kabupaten Banggai Kepulauan',
    23 => 'Kabupaten Banggai Laut',
    24 => 'Kabupaten Bangkalan',
    25 => 'Kabupaten Bangli',
    26 => 'Kabupaten Banjar',
    27 => 'Kabupaten Banjarnegara',
    28 => 'Kabupaten Bantaeng',
    29 => 'Kabupaten Bantul',
    30 => 'Kabupaten Banyuasin',
    31 => 'Kabupaten Banyumas',
    32 => 'Kabupaten Banyuwangi',
    33 => 'Kabupaten Barito Kuala',
    34 => 'Kabupaten Barito Selatan',
    35 => 'Kabupaten Barito Timur',
    36 => 'Kabupaten Barito Utara',
    37 => 'Kabupaten Barru',
    38 => 'Kabupaten Batang',
    39 => 'Kabupaten Batanghari',
    40 => 'Kabupaten Batu Bara',
    41 => 'Kabupaten Bekasi',
    42 => 'Kabupaten Belu',
    43 => 'Kabupaten Bener Meriah',
    44 => 'Kabupaten Bengkalis',
    45 => 'Kabupaten Bengkayang',
    46 => 'Kabupaten Berau',
    47 => 'Kabupaten Biak Numfor',
    48 => 'Kabupaten Bima',
    49 => 'Kabupaten Bireuen',
    50 => 'Kabupaten Blitar',
    51 => 'Kabupaten Blora',
    52 => 'Kabupaten Boalemo',
    53 => 'Kabupaten Bogor',
    54 => 'Kabupaten Bojonegoro',
    55 => 'Kabupaten Bolaang Mongondow',
    56 => 'Kabupaten Bolaang Mongondow Selatan',
    57 => 'Kabupaten Bolaang Mongondow Timur',
    58 => 'Kabupaten Bolaang Mongondow Utara',
    59 => 'Kabupaten Bombana',
    60 => 'Kabupaten Bondowoso',
    61 => 'Kabupaten Bone',
    62 => 'Kabupaten Bone Bolango',
    63 => 'Kabupaten Boven Digoel',
    64 => 'Kabupaten Boyolali',
    65 => 'Kabupaten Brebes',
    66 => 'Kabupaten Buleleng',
    67 => 'Kabupaten Bulukumba',
    68 => 'Kabupaten Bulungan',
    69 => 'Kabupaten Bungo',
    70 => 'Kabupaten Buol',
    71 => 'Kabupaten Buton',
    72 => 'Kabupaten Buton Selatan',
    73 => 'Kabupaten Buton Tengah',
    74 => 'Kabupaten Buton Utara',
    75 => 'Kabupaten Ciamis',
    76 => 'Kabupaten Cianjur',
    77 => 'Kabupaten Cilacap',
    78 => 'Kabupaten Cirebon',
    79 => 'Kabupaten Dairi',
    80 => 'Kabupaten Deiyai',
    81 => 'Kabupaten Deli Serdang',
    82 => 'Kabupaten Demak',
    83 => 'Kabupaten Dharmasraya',
    84 => 'Kabupaten Dogiyai',
    85 => 'Kabupaten Dompu',
    86 => 'Kabupaten Donggala',
    87 => 'Kabupaten Empat Lawang',
    88 => 'Kabupaten Ende',
    89 => 'Kabupaten Enrekang',
    90 => 'Kabupaten Fakfak',
    91 => 'Kabupaten Flores Timur',
    92 => 'Kabupaten Garut',
    93 => 'Kabupaten Gayo Lues',
    94 => 'Kabupaten Gianyar',
    95 => 'Kabupaten Gorontalo',
    96 => 'Kabupaten Gorontalo Utara',
    97 => 'Kabupaten Gowa',
    98 => 'Kabupaten Gresik',
    99 => 'Kabupaten Grobogan',
    100 => 'Kabupaten Gunung Mas',
    101 => 'Kabupaten Gunungkidul',
    102 => 'Kabupaten Halmahera Barat',
    103 => 'Kabupaten Halmahera Selatan',
    104 => 'Kabupaten Halmahera Tengah',
    105 => 'Kabupaten Halmahera Timur',
    106 => 'Kabupaten Halmahera Utara',
    107 => 'Kabupaten Hulu Sungai Selatan',
    108 => 'Kabupaten Hulu Sungai Tengah',
    109 => 'Kabupaten Hulu Sungai Utara',
    110 => 'Kabupaten Humbang Hasundutan',
    111 => 'Kabupaten Indragiri Hilir',
    112 => 'Kabupaten Indragiri Hulu',
    113 => 'Kabupaten Indramayu',
    114 => 'Kabupaten Intan Jaya',
    115 => 'Kabupaten Jayapura',
    116 => 'Kabupaten Jayawijaya',
    117 => 'Kabupaten Jember',
    118 => 'Kabupaten Jembrana',
    119 => 'Kabupaten Jeneponto',
    120 => 'Kabupaten Jepara',
    121 => 'Kabupaten Jombang',
    122 => 'Kabupaten Kaimana',
    123 => 'Kabupaten Kampar',
    124 => 'Kabupaten Kapuas',
    125 => 'Kabupaten Kapuas Hulu',
    126 => 'Kabupaten Karanganyar',
    127 => 'Kabupaten Karangasem',
    128 => 'Kabupaten Karawang',
    129 => 'Kabupaten Karo',
    130 => 'Kabupaten Katingan',
    131 => 'Kabupaten Kayong Utara',
    132 => 'Kabupaten Kebumen',
    133 => 'Kabupaten Kediri',
    134 => 'Kabupaten Keerom',
    135 => 'Kabupaten Kendal',
    136 => 'Kabupaten Kepulauan Mentawai',
    137 => 'Kabupaten Kepulauan Meranti',
    138 => 'Kabupaten Kepulauan Sangihe',
    139 => 'Kabupaten Kepulauan Selayar',
    140 => 'Kabupaten Kepulauan Siau Tagulandang Biaro',
    141 => 'Kabupaten Kepulauan Sula',
    142 => 'Kabupaten Kepulauan Talaud',
    143 => 'Kabupaten Kepulauan Yapen',
    144 => 'Kabupaten Kerinci',
    145 => 'Kabupaten Ketapang',
    146 => 'Kabupaten Klaten',
    147 => 'Kabupaten Klungkung',
    148 => 'Kabupaten Kolaka',
    149 => 'Kabupaten Kolaka Timur',
    150 => 'Kabupaten Kolaka Utara',
    151 => 'Kabupaten Konawe',
    152 => 'Kabupaten Konawe Kepulauan',
    153 => 'Kabupaten Konawe Selatan',
    154 => 'Kabupaten Konawe Utara',
    155 => 'Kabupaten Kotabaru',
    156 => 'Kabupaten Kotawaringin Barat',
    157 => 'Kabupaten Kotawaringin Timur',
    158 => 'Kabupaten Kuantan Singingi',
    159 => 'Kabupaten Kubu Raya',
    160 => 'Kabupaten Kudus',
    161 => 'Kabupaten Kulon Progo',
    162 => 'Kabupaten Kuningan',
    163 => 'Kabupaten Kupang',
    164 => 'Kabupaten Kutai Barat',
    165 => 'Kabupaten Kutai Kartanegara',
    166 => 'Kabupaten Kutai Timur',
    167 => 'Kabupaten Labuhanbatu',
    168 => 'Kabupaten Labuhanbatu Selatan',
    169 => 'Kabupaten Labuhanbatu Utara',
    170 => 'Kabupaten Lahat',
    171 => 'Kabupaten Lamandau',
    172 => 'Kabupaten Lamongan',
    173 => 'Kabupaten Lampung Barat',
    174 => 'Kabupaten Lampung Selatan',
    175 => 'Kabupaten Lampung Tengah',
    176 => 'Kabupaten Lampung Timur',
    177 => 'Kabupaten Lampung Utara',
    178 => 'Kabupaten Landak',
    179 => 'Kabupaten Langkat',
    180 => 'Kabupaten Lanny Jaya',
    181 => 'Kabupaten Lebak',
    182 => 'Kabupaten Lembata',
    183 => 'Kabupaten Lima Puluh Kota',
    184 => 'Kabupaten Lombok Barat',
    185 => 'Kabupaten Lombok Tengah',
    186 => 'Kabupaten Lombok Timur',
    187 => 'Kabupaten Lombok Utara',
    188 => 'Kabupaten Lumajang',
    189 => 'Kabupaten Luwu',
    190 => 'Kabupaten Luwu Timur',
    191 => 'Kabupaten Luwu Utara',
    192 => 'Kabupaten Madiun',
    193 => 'Kabupaten Magelang',
    194 => 'Kabupaten Magetan',
    195 => 'Kabupaten Mahakam Ulu',
    196 => 'Kabupaten Majalengka',
    197 => 'Kabupaten Majene',
    198 => 'Kabupaten Malaka',
    199 => 'Kabupaten Malang',
    200 => 'Kabupaten Malinau',
    201 => 'Kabupaten Mamasa',
    202 => 'Kabupaten Mamberamo Raya',
    203 => 'Kabupaten Mamberamo Tengah',
    204 => 'Kabupaten Mamuju',
    205 => 'Kabupaten Mamuju Tengah',
    206 => 'Kabupaten Mandailing Natal',
    207 => 'Kabupaten Manggarai',
    208 => 'Kabupaten Manggarai Barat',
    209 => 'Kabupaten Manggarai Timur',
    210 => 'Kabupaten Manokwari',
    211 => 'Kabupaten Manokwari Selatan',
    212 => 'Kabupaten Mappi',
    213 => 'Kabupaten Maros',
    214 => 'Kabupaten Maybrat',
    215 => 'Kabupaten Melawi',
    216 => 'Kabupaten Mempawah',
    217 => 'Kabupaten Merangin',
    218 => 'Kabupaten Merauke',
    219 => 'Kabupaten Mesuji',
    220 => 'Kabupaten Mimika',
    221 => 'Kabupaten Minahasa',
    222 => 'Kabupaten Minahasa Selatan',
    223 => 'Kabupaten Minahasa Tenggara',
    224 => 'Kabupaten Minahasa Utara',
    225 => 'Kabupaten Mojokerto',
    226 => 'Kabupaten Morowali',
    227 => 'Kabupaten Morowali Utara',
    228 => 'Kabupaten Muara Enim',
    229 => 'Kabupaten Muaro Jambi',
    230 => 'Kabupaten Muna',
    231 => 'Kabupaten Muna Barat',
    232 => 'Kabupaten Murung Raya',
    233 => 'Kabupaten Musi Banyuasin',
    234 => 'Kabupaten Musi Rawas',
    235 => 'Kabupaten Musi Rawas Utara',
    236 => 'Kabupaten Nabire',
    237 => 'Kabupaten Nagan Raya',
    238 => 'Kabupaten Nagekeo',
    239 => 'Kabupaten Nduga',
    240 => 'Kabupaten Ngada',
    241 => 'Kabupaten Nganjuk',
    242 => 'Kabupaten Ngawi',
    243 => 'Kabupaten Nias',
    244 => 'Kabupaten Nias Barat',
    245 => 'Kabupaten Nias Selatan',
    246 => 'Kabupaten Nias Utara',
    247 => 'Kabupaten Nunukan',
    248 => 'Kabupaten Ogan Ilir',
    249 => 'Kabupaten Ogan Komering Ilir',
    250 => 'Kabupaten Ogan Komering Ulu',
    251 => 'Kabupaten Ogan Komering Ulu Selatan',
    252 => 'Kabupaten Ogan Komering Ulu Timur',
    253 => 'Kabupaten Pacitan',
    254 => 'Kabupaten Padang Lawas',
    255 => 'Kabupaten Padang Lawas Utara',
    256 => 'Kabupaten Padang Pariaman',
    257 => 'Kabupaten Pakpak Bharat',
    258 => 'Kabupaten Pamekasan',
    259 => 'Kabupaten Pandeglang',
    260 => 'Kabupaten Pangandaran',
    261 => 'Kabupaten Pangkajene dan Kepulauan',
    262 => 'Kabupaten Paniai',
    263 => 'Kabupaten Parigi Moutong',
    264 => 'Kabupaten Pasaman',
    265 => 'Kabupaten Pasaman Barat',
    266 => 'Kabupaten Pasangkayu',
    267 => 'Kabupaten Paser',
    268 => 'Kabupaten Pasuruan',
    269 => 'Kabupaten Pati',
    270 => 'Kabupaten Pegunungan Arfak',
    271 => 'Kabupaten Pegunungan Bintang',
    272 => 'Kabupaten Pekalongan',
    273 => 'Kabupaten Pelalawan',
    274 => 'Kabupaten Pemalang',
    275 => 'Kabupaten Penajam Paser Utara',
    276 => 'Kabupaten Penukal Abab Lematang Ilir',
    277 => 'Kabupaten Pesawaran',
    278 => 'Kabupaten Pesisir Barat',
    279 => 'Kabupaten Pesisir Selatan',
    280 => 'Kabupaten Pidie',
    281 => 'Kabupaten Pidie Jaya',
    282 => 'Kabupaten Pinrang',
    283 => 'Kabupaten Pohuwato',
    284 => 'Kabupaten Polewali Mandar',
    285 => 'Kabupaten Ponorogo',
    286 => 'Kabupaten Poso',
    287 => 'Kabupaten Pringsewu',
    288 => 'Kabupaten Probolinggo',
    289 => 'Kabupaten Pulang Pisau',
    290 => 'Kabupaten Pulau Morotai',
    291 => 'Kabupaten Pulau Taliabu',
    292 => 'Kabupaten Puncak',
    293 => 'Kabupaten Puncak Jaya',
    294 => 'Kabupaten Purbalingga',
    295 => 'Kabupaten Purwakarta',
    296 => 'Kabupaten Purworejo',
    297 => 'Kabupaten Raja Ampat',
    298 => 'Kabupaten Rembang',
    299 => 'Kabupaten Rokan Hilir',
    300 => 'Kabupaten Rokan Hulu',
    301 => 'Kabupaten Rote Ndao',
    302 => 'Kabupaten Sabu Raijua',
    303 => 'Kabupaten Sambas',
    304 => 'Kabupaten Samosir',
    305 => 'Kabupaten Sampang',
    306 => 'Kabupaten Sanggau',
    307 => 'Kabupaten Sarmi',
    308 => 'Kabupaten Sarolangun',
    309 => 'Kabupaten Sekadau',
    310 => 'Kabupaten Semarang',
    311 => 'Kabupaten Serang',
    312 => 'Kabupaten Serdang Bedagai',
    313 => 'Kabupaten Seruyan',
    314 => 'Kabupaten Siak',
    315 => 'Kabupaten Sidenreng Rappang',
    316 => 'Kabupaten Sidoarjo',
    317 => 'Kabupaten Sigi',
    318 => 'Kabupaten Sijunjung',
    319 => 'Kabupaten Sikka',
    320 => 'Kabupaten Simalungun',
    321 => 'Kabupaten Simeulue',
    322 => 'Kabupaten Sinjai',
    323 => 'Kabupaten Sintang',
    324 => 'Kabupaten Situbondo',
    325 => 'Kabupaten Sleman',
    326 => 'Kabupaten Solok',
    327 => 'Kabupaten Solok Selatan',
    328 => 'Kabupaten Soppeng',
    329 => 'Kabupaten Sorong',
    330 => 'Kabupaten Sorong Selatan',
    331 => 'Kabupaten Sragen',
    332 => 'Kabupaten Subang',
    333 => 'Kabupaten Sukabumi',
    334 => 'Kabupaten Sukamara',
    335 => 'Kabupaten Sukoharjo',
    336 => 'Kabupaten Sumba Barat',
    337 => 'Kabupaten Sumba Barat Daya',
    338 => 'Kabupaten Sumba Tengah',
    339 => 'Kabupaten Sumba Timur',
    340 => 'Kabupaten Sumbawa',
    341 => 'Kabupaten Sumbawa Barat',
    342 => 'Kabupaten Sumedang',
    343 => 'Kabupaten Sumenep',
    344 => 'Kabupaten Supiori',
    345 => 'Kabupaten Tabalong',
    346 => 'Kabupaten Tabanan',
    347 => 'Kabupaten Takalar',
    348 => 'Kabupaten Tambrauw',
    349 => 'Kabupaten Tana Tidung',
    350 => 'Kabupaten Tana Toraja',
    351 => 'Kabupaten Tanah Bumbu',
    352 => 'Kabupaten Tanah Datar',
    353 => 'Kabupaten Tanah Laut',
    354 => 'Kabupaten Tangerang',
    355 => 'Kabupaten Tanggamus',
    356 => 'Kabupaten Tanjung Jabung Barat',
    357 => 'Kabupaten Tanjung Jabung Timur',
    358 => 'Kabupaten Tapanuli Selatan',
    359 => 'Kabupaten Tapanuli Tengah',
    360 => 'Kabupaten Tapanuli Utara',
    361 => 'Kabupaten Tapin',
    362 => 'Kabupaten Tasikmalaya',
    363 => 'Kabupaten Tebo',
    364 => 'Kabupaten Tegal',
    365 => 'Kabupaten Teluk Bintuni',
    366 => 'Kabupaten Teluk Wondama',
    367 => 'Kabupaten Temanggung',
    368 => 'Kabupaten Timor Tengah Selatan',
    369 => 'Kabupaten Timor Tengah Utara',
    370 => 'Kabupaten Toba',
    371 => 'Kabupaten Tojo Una-Una',
    372 => 'Kabupaten Tolikara',
    373 => 'Kabupaten Tolitoli',
    374 => 'Kabupaten Toraja Utara',
    375 => 'Kabupaten Trenggalek',
    376 => 'Kabupaten Tuban',
    377 => 'Kabupaten Tulang Bawang',
    378 => 'Kabupaten Tulang Bawang Barat',
    379 => 'Kabupaten Tulungagung',
    380 => 'Kabupaten Wajo',
    381 => 'Kabupaten Wakatobi',
    382 => 'Kabupaten Waropen',
    383 => 'Kabupaten Way Kanan',
    384 => 'Kabupaten Wonogiri',
    385 => 'Kabupaten Wonosobo',
    386 => 'Kabupaten Yahukimo',
    387 => 'Kabupaten Yalimo',
    388 => 'Kota Administrasi Jakarta Barat',
    389 => 'Kota Administrasi Jakarta Pusat',
    390 => 'Kota Administrasi Jakarta Selatan',
    391 => 'Kota Administrasi Jakarta Timur',
    392 => 'Kota Administrasi Jakarta Utara',
    393 => 'Kota Balikpapan',
    394 => 'Kota Banda Aceh',
    395 => 'Kota Bandar Lampung',
    396 => 'Kota Bandung',
    397 => 'Kota Banjar',
    398 => 'Kota Banjarbaru',
    399 => 'Kota Banjarmasin',
    400 => 'Kota Batu',
    401 => 'Kota Baubau',
    402 => 'Kota Bekasi',
    403 => 'Kota Bima',
    404 => 'Kota Binjai',
    405 => 'Kota Bitung',
    406 => 'Kota Blitar',
    407 => 'Kota Bogor',
    408 => 'Kota Bontang',
    409 => 'Kota Bukittinggi',
    410 => 'Kota Cilegon',
    411 => 'Kota Cimahi',
    412 => 'Kota Cirebon',
    413 => 'Kota Denpasar',
    414 => 'Kota Depok',
    415 => 'Kota Dumai',
    416 => 'Kota Gorontalo',
    417 => 'Kota Gunungsitoli',
    418 => 'Kota Jambi',
    419 => 'Kota Jayapura',
    420 => 'Kota Kediri',
    421 => 'Kota Kendari',
    422 => 'Kota Kotamobagu',
    423 => 'Kota Kupang',
    424 => 'Kota Langsa',
    425 => 'Kota Lhokseumawe',
    426 => 'Kota Lubuk Linggau',
    427 => 'Kota Madiun',
    428 => 'Kota Magelang',
    429 => 'Kota Makassar',
    430 => 'Kota Malang',
    431 => 'Kota Manado',
    432 => 'Kota Mataram',
    433 => 'Kota Medan',
    434 => 'Kota Metro',
    435 => 'Kota Mojokerto',
    436 => 'Kota Padang',
    437 => 'Kota Padang Panjang',
    438 => 'Kota Padangsidimpuan',
    439 => 'Kota Pagaralam',
    440 => 'Kota Palangka Raya',
    441 => 'Kota Palembang',
    442 => 'Kota Palopo',
    443 => 'Kota Palu',
    444 => 'Kota Parepare',
    445 => 'Kota Pariaman',
    446 => 'Kota Pasuruan',
    447 => 'Kota Payakumbuh',
    448 => 'Kota Pekalongan',
    449 => 'Kota Pekanbaru',
    450 => 'Kota Pematangsiantar',
    451 => 'Kota Pontianak',
    452 => 'Kota Prabumulih',
    453 => 'Kota Probolinggo',
    454 => 'Kota Sabang',
    455 => 'Kota Salatiga',
    456 => 'Kota Samarinda',
    457 => 'Kota Sawahlunto',
    458 => 'Kota Semarang',
    459 => 'Kota Serang',
    460 => 'Kota Sibolga',
    461 => 'Kota Singkawang',
    462 => 'Kota Solok',
    463 => 'Kota Sorong',
    464 => 'Kota Subulussalam',
    465 => 'Kota Sukabumi',
    466 => 'Kota Sungai Penuh',
    467 => 'Kota Surabaya',
    468 => 'Kota Surakarta',
    469 => 'Kota Tangerang',
    470 => 'Kota Tangerang Selatan',
    471 => 'Kota Tanjungbalai',
    472 => 'Kota Tarakan',
    473 => 'Kota Tasikmalaya',
    474 => 'Kota Tebing Tinggi',
    475 => 'Kota Tegal',
    476 => 'Kota Ternate',
    477 => 'Kota Tidore Kepulauan',
    478 => 'Kota Tomohon',
    479 => 'Kota Yogyakarta',
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'daxtro',
        'prefix' => '',
        'foreign_key_constraints' => true,
        'busy_timeout' => NULL,
        'journal_mode' => NULL,
        'synchronous' => NULL,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'daxtro',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'daxtro',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'daxtro',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'daxtro',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 
    array (
      'table' => 'migrations',
      'update_date_on_publish' => true,
    ),
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel_database_',
        'persistent' => false,
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\app/private',
        'serve' => true,
        'throw' => true,
        'report' => true,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
        'throw' => false,
        'report' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'report' => false,
      ),
    ),
    'links' => 
    array (
      'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\public\\storage' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\app/public',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'handler_with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'formatter' => NULL,
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'log',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'scheme' => NULL,
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '2525',
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => 'localhost',
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
        'retry_after' => 60,
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
        'retry_after' => 60,
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Laravel',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'provinces' => 
  array (
    0 => 'Tidak ada dalam list',
    1 => 'DKI Jakarta',
    2 => 'Jawa Barat',
    3 => 'Jawa Tengah',
    4 => 'DI Yogyakarta',
    5 => 'Banten',
    6 => 'Jawa Timur',
    7 => 'Bali',
    8 => 'Aceh',
    9 => 'Sumatera Utara',
    10 => 'Sumatera Barat',
    11 => 'Riau',
    12 => 'Jambi',
    13 => 'Bengkulu',
    14 => 'Lampung',
    15 => 'Kalimantan Barat',
    16 => 'Kalimantan Tengah',
    17 => 'Kalimantan Selatan',
    18 => 'Kalimantan Timur',
    19 => 'Sulawesi Utara',
    20 => 'Sulawesi Tengah',
    21 => 'Sulawesi Selatan',
    22 => 'Gorontalo',
    23 => 'Sulawesi Barat',
    24 => 'Maluku Utara',
    25 => 'Papua',
    26 => 'Papua Barat',
    27 => 'Papua Selatan',
    28 => 'Papua Tengah',
    29 => 'Papua Pegunungan',
    30 => 'Papua Barat Daya',
    31 => 'Nusa Tenggara Barat',
    32 => 'Nusa Tenggara Timur',
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
    'lead_register_api_token' => '',
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'reverb' => 
      array (
        'driver' => 'reverb',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'host' => NULL,
          'port' => 443,
          'scheme' => 'https',
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'cluster' => NULL,
          'host' => 'api-mt1.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'concurrency' => 
  array (
    'default' => 'process',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => '12',
      'verify' => true,
      'limit' => NULL,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
      'verify' => true,
    ),
    'rehash_on_login' => true,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\resources\\views',
    ),
    'compiled' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\framework\\views',
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'public_path' => NULL,
    'convert_entities' => true,
    'options' => 
    array (
      'font_dir' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\fonts',
      'font_cache' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\storage\\fonts',
      'temp_dir' => 'C:\\Users\\Asus\\AppData\\Local\\Temp',
      'chroot' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com',
      'allowed_protocols' => 
      array (
        'data://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'file://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'http://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'https://' => 
        array (
          'rules' => 
          array (
          ),
        ),
      ),
      'artifactPathValidation' => NULL,
      'log_output_file' => NULL,
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_paper_orientation' => 'portrait',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => false,
      'allowed_remote_hosts' => NULL,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => true,
    ),
  ),
  'livewire' => 
  array (
    'class_namespace' => 'App\\Livewire',
    'view_path' => 'C:\\Users\\Asus\\OneDrive\\Desktop\\Sasha\\Kuliah\\ERP\\sys.daxtro.com\\resources\\views/livewire',
    'layout' => 'components.layouts.app',
    'lazy_placeholder' => NULL,
    'temporary_file_upload' => 
    array (
      'disk' => NULL,
      'rules' => NULL,
      'directory' => NULL,
      'middleware' => NULL,
      'preview_mimes' => 
      array (
        0 => 'png',
        1 => 'gif',
        2 => 'bmp',
        3 => 'svg',
        4 => 'wav',
        5 => 'mp4',
        6 => 'mov',
        7 => 'avi',
        8 => 'wmv',
        9 => 'mp3',
        10 => 'm4a',
        11 => 'jpg',
        12 => 'jpeg',
        13 => 'mpga',
        14 => 'webp',
        15 => 'wma',
      ),
      'max_upload_time' => 5,
      'cleanup' => true,
    ),
    'render_on_redirect' => false,
    'legacy_model_binding' => false,
    'inject_assets' => true,
    'navigate' => 
    array (
      'show_progress_bar' => true,
      'progress_bar_color' => '#2299dd',
    ),
    'inject_morph_markers' => true,
    'pagination_theme' => 'tailwind',
  ),
  'datatables-buttons' => 
  array (
    'namespace' => 
    array (
      'base' => 'DataTables',
      'model' => 'App\\Models',
    ),
    'pdf_generator' => 'snappy',
    'snappy' => 
    array (
      'options' => 
      array (
        'no-outline' => true,
        'margin-left' => '0',
        'margin-right' => '0',
        'margin-top' => '10mm',
        'margin-bottom' => '10mm',
      ),
      'orientation' => 'landscape',
    ),
    'parameters' => 
    array (
      'dom' => 'Bfrtip',
      'order' => 
      array (
        0 => 
        array (
          0 => 0,
          1 => 'desc',
        ),
      ),
      'buttons' => 
      array (
        0 => 'excel',
        1 => 'csv',
        2 => 'pdf',
        3 => 'print',
        4 => 'reset',
        5 => 'reload',
      ),
    ),
    'generator' => 
    array (
      'columns' => 'id,add your columns,created_at,updated_at',
      'buttons' => 'excel,csv,pdf,print,reset,reload',
      'dom' => 'Bfrtip',
    ),
  ),
  'datatables-html' => 
  array (
    'namespace' => 'LaravelDataTables',
    'table' => 
    array (
      'class' => 'table',
      'id' => 'dataTableBuilder',
    ),
    'script' => 'datatables::script',
    'editor' => 'datatables::editor',
  ),
  'datatables-export' => 
  array (
    'method' => 'lazy',
    'chunk' => 1000,
    'disk' => 'local',
    's3_disk' => '',
    'mail_from' => 'hello@example.com',
    'default_date_format' => 'yyyy-mm-dd',
    'date_formats' => 
    array (
      0 => 'mm/dd/yyyy',
      1 => 'yyyy-mm-dd',
      2 => 'dd/mm/yyyy',
      3 => 'd/m/yy',
      4 => 'd-m-yy',
      5 => 'd-m',
      6 => 'm-yy',
      7 => 'mm-dd-yy',
      8 => 'm/d/yyyy',
      9 => 'd-mmm-yy',
      10 => 'd-mmm',
      11 => 'mmm-yy',
      12 => 'm/d/yy h:mm',
      13 => 'm/d/yyyy h:mm',
      14 => 'd/m/yy h:mm',
      15 => 'h:mm AM/PM',
      16 => 'h:mm:ss AM/PM',
      17 => 'h:mm',
      18 => 'h:mm:ss',
      19 => 'mm:ss',
      20 => 'h:mm:ss',
      21 => 'i:s.S',
      22 => 'h:mm:ss;@',
      23 => 'yyyy/mm/dd;@',
      24 => 'dddd, mmmm d, yyyy',
      25 => 'm/d/yy h:mm',
      26 => 'd/m/yy h:mm',
      27 => 'h:mm AM/PM',
      28 => 'h:mm:ss AM/PM',
      29 => 'h:mm',
      30 => 'h:mm:ss',
      31 => 'mm:ss',
      32 => 'h:mm:ss',
      33 => 'i:s.S',
      34 => 'h:mm:ss;@',
    ),
    'text_formats' => 
    array (
      0 => '@',
      1 => 'General',
    ),
    'purge' => 
    array (
      'days' => 1,
    ),
  ),
  'datatables' => 
  array (
    'search' => 
    array (
      'smart' => true,
      'multi_term' => true,
      'case_insensitive' => true,
      'use_wildcards' => false,
      'starts_with' => false,
    ),
    'index_column' => 'DT_RowIndex',
    'engines' => 
    array (
      'eloquent' => 'Yajra\\DataTables\\EloquentDataTable',
      'query' => 'Yajra\\DataTables\\QueryDataTable',
      'collection' => 'Yajra\\DataTables\\CollectionDataTable',
      'resource' => 'Yajra\\DataTables\\ApiResourceDataTable',
    ),
    'builders' => 
    array (
    ),
    'nulls_last_sql' => ':column :direction NULLS LAST',
    'error' => NULL,
    'columns' => 
    array (
      'excess' => 
      array (
        0 => 'rn',
        1 => 'row_num',
      ),
      'escape' => '*',
      'raw' => 
      array (
        0 => 'action',
      ),
      'blacklist' => 
      array (
        0 => 'password',
        1 => 'remember_token',
      ),
      'whitelist' => '*',
    ),
    'json' => 
    array (
      'header' => 
      array (
      ),
      'options' => 0,
    ),
    'callback' => 
    array (
      0 => '$',
      1 => '$.',
      2 => 'function',
    ),
  ),
  'datatables-fractal' => 
  array (
    'includes' => 'include',
    'serializer' => 'League\\Fractal\\Serializer\\DataArraySerializer',
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
