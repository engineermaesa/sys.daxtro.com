<div class="d-flex justify-content-end mb-2">
    <a href="{{ $url }}" class="btn btn-sm btn-primary">
        <i class="bi bi-plus-circle me-1"></i> Add {{  $title }}
    </a>
</div>