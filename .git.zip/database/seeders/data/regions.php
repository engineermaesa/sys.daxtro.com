<?php
return '
[
 {
   "Regional": "Jawa",
   "Provinsi": "DKI Jakarta",
   "Region": "Kabupaten Administrasi Kepulauan Seribu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DKI Jakarta",
   "Region": "Kota Administrasi Jakarta Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DKI Jakarta",
   "Region": "Kota Administrasi Jakarta Pusat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DKI Jakarta",
   "Region": "Kota Administrasi Jakarta Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DKI Jakarta",
   "Region": "Kota Administrasi Jakarta Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DKI Jakarta",
   "Region": "Kota Administrasi Jakarta Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Bandung",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Bandung Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Bekasi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Bogor",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Ciamis",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Cianjur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Cirebon",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Garut",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Indramayu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Karawang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Kuningan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Majalengka",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Pangandaran",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Purwakarta",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Subang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Sukabumi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Sumedang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kabupaten Tasikmalaya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Bandung",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Banjar",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Bekasi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Bogor",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Cimahi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Cirebon",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Depok",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Sukabumi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Barat",
   "Region": "Kota Tasikmalaya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Banjarnegara",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Banyumas",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Batang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Blora",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Boyolali",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Brebes",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Cilacap",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Demak",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Grobogan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Jepara",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Karanganyar",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Kebumen",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Kendal",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Klaten",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Kudus",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Magelang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Pati",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Pekalongan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Pemalang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Purbalingga",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Purworejo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Rembang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Semarang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Sragen",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Sukoharjo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Tegal",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Temanggung",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Wonogiri",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kabupaten Wonosobo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kota Magelang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kota Pekalongan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kota Salatiga",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kota Semarang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kota Surakarta",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Tengah",
   "Region": "Kota Tegal",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Bantul",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Gunungkidul",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Kulon Progo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Sleman",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kota Yogyakarta",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kabupaten Lebak",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kabupaten Pandeglang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kabupaten Serang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kabupaten Tangerang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kota Cilegon",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kota Serang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kota Tangerang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Banten",
   "Region": "Kota Tangerang Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Mojokerto",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Blitar",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Madiun",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Pasuruan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Probolinggo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Kediri",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Malang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Batu",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kota Surabaya",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Magetan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Sidoarjo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Pamekasan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Mojokerto",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Jombang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Madiun",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Tulungagung",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Sampang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Trenggalek",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Gresik",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Nganjuk",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Bangkalan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Ngawi",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Ponorogo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Pacitan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Pasuruan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Kediri",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Bondowoso",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Situbondo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Probolinggo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Lamongan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Blitar",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Lumajang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Tuban",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Sumenep",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Bojonegoro",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Jember",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Malang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "Jawa Timur",
   "Region": "Kabupaten Banyuwangi",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Badung",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Bangli",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Buleleng",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Gianyar",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Jembrana",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Karangasem",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Klungkung",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kabupaten Tabanan",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Kep. Nusa Tenggara",
   "Provinsi": "Bali",
   "Region": "Kota Denpasar",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Gayo Lues",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Tengah",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Tenggara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Jaya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Nagan Raya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Pidie",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Besar",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Tamiang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Bener Meriah",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Barat Daya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Aceh Singkil",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Simeulue",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Bireuen",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kota Subulussalam",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kabupaten Pidie Jaya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kota Langsa",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kota Lhokseumawe",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kota Sabang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Aceh",
   "Region": "Kota Banda Aceh",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Asahan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Batu Bara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Dairi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Deli Serdang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Humbang Hasundutan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Karo",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Labuhanbatu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Labuhanbatu Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Labuhanbatu Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Langkat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Mandailing Natal",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Nias",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Nias Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Nias Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Nias Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Padang Lawas",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Padang Lawas Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Pakpak Bharat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Samosir",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Serdang Bedagai",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Simalungun",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Tapanuli Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Tapanuli Tengah",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Tapanuli Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kabupaten Toba",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Binjai",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Gunungsitoli",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Medan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Padangsidimpuan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Pematangsiantar",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Sibolga",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Tanjungbalai",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Utara",
   "Region": "Kota Tebing Tinggi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Agam",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Dharmasraya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Kepulauan Mentawai",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Lima Puluh Kota",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Padang Pariaman",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Pasaman",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Pasaman Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Pesisir Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Sijunjung",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Solok",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Solok Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kabupaten Tanah Datar",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kota Bukittinggi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kota Padang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kota Padang Panjang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kota Pariaman",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kota Payakumbuh",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kota Sawahlunto",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Sumatera Barat",
   "Region": "Kota Solok",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Bengkalis",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Indragiri Hilir",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Indragiri Hulu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Kampar",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Kepulauan Meranti",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Kuantan Singingi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Pelalawan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Rokan Hilir",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Rokan Hulu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kabupaten Siak",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kota Dumai",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Riau",
   "Region": "Kota Pekanbaru",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Batanghari",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Bungo",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Kerinci",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Merangin",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Muaro Jambi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Sarolangun",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Tanjung Jabung Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Tanjung Jabung Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kabupaten Tebo",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kota Jambi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Jambi",
   "Region": "Kota Sungai Penuh",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Banyuasin",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Empat Lawang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Lahat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Muara Enim",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Musi Banyuasin",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Musi Rawas",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Musi Rawas Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Ogan Ilir",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Ogan Komering Ilir",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Ogan Komering Ulu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Ogan Komering Ulu Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Ogan Komering Ulu Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kabupaten Penukal Abab Lematang Ilir",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kota Lubuk Linggau",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kota Pagaralam",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kota Palembang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Bengkulu",
   "Region": "Kota Prabumulih",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Lampung Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Lampung Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Lampung Tengah",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Lampung Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Lampung Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Mesuji",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Pesawaran",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Pesisir Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Pringsewu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Tanggamus",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Tulang Bawang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Tulang Bawang Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kabupaten Way Kanan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kota Bandar Lampung",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sumatera",
   "Provinsi": "Lampung",
   "Region": "Kota Metro",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Bengkayang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Kapuas Hulu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Kayong Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Ketapang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Kubu Raya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Landak",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Melawi",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Mempawah",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Sambas",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Sanggau",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Sekadau",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kabupaten Sintang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kota Pontianak",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Barat",
   "Region": "Kota Singkawang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Barito Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Barito Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Barito Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Gunung Mas",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Kapuas",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Katingan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Kotawaringin Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Kotawaringin Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Lamandau",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Murung Raya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Pulang Pisau",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Seruyan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kabupaten Sukamara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Tengah",
   "Region": "Kota Palangka Raya",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Balangan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Banjar",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Barito Kuala",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Hulu Sungai Selatan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Hulu Sungai Tengah",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Hulu Sungai Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Kotabaru",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Tabalong",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Tanah Bumbu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Tanah Laut",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Tapin",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kota Banjarbaru",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kota Banjarmasin",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kabupaten Berau",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kabupaten Kutai Barat",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kabupaten Kutai Kartanegara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kabupaten Kutai Timur",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kabupaten Mahakam Ulu",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kabupaten Paser",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kabupaten Penajam Paser Utara",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kota Balikpapan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kota Bontang",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Timur",
   "Region": "Kota Samarinda",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Bulungan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Malinau",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Nunukan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kabupaten Tana Tidung",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Kalimantan",
   "Provinsi": "Kalimantan Selatan",
   "Region": "Kota Tarakan",
   "Branch": "Branch Jakarta"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Bolaang Mongondow",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Bolaang Mongondow Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Bolaang Mongondow Timur",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Bolaang Mongondow Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Kepulauan Sangihe",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Kepulauan Siau Tagulandang Biaro",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Kepulauan Talaud",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Minahasa",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Minahasa Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Minahasa Tenggara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kabupaten Minahasa Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kota Bitung",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kota Kotamobagu",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kota Manado",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Utara",
   "Region": "Kota Tomohon",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Banggai",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Banggai Kepulauan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Banggai Laut",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Buol",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Donggala",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Morowali",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Morowali Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Parigi Moutong",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Poso",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Sigi",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Tojo Una-Una",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Tolitoli",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kota Palu",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Bantaeng",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Barru",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Bone",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Bulukumba",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Enrekang",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Gowa",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Jeneponto",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Kepulauan Selayar",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Luwu",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Luwu Timur",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Luwu Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Maros",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Pangkajene dan Kepulauan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Pinrang",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Sidenreng Rappang",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Sinjai",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Soppeng",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Takalar",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Tana Toraja",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Toraja Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kabupaten Wajo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kota Makassar",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kota Parepare",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Selatan",
   "Region": "Kota Palopo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Bombana",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Buton",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Buton Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Buton Tengah",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Buton Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Kolaka",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Kolaka Timur",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Kolaka Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Konawe",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Konawe Kepulauan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Konawe Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Konawe Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Muna",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Muna Barat",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kabupaten Wakatobi",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kota Baubau",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Tengah",
   "Region": "Kota Kendari",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Gorontalo",
   "Region": "Kabupaten Boalemo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Gorontalo",
   "Region": "Kabupaten Bone Bolango",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Gorontalo",
   "Region": "Kabupaten Gorontalo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Gorontalo",
   "Region": "Kabupaten Gorontalo Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Gorontalo",
   "Region": "Kabupaten Pohuwato",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Gorontalo",
   "Region": "Kota Gorontalo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Barat",
   "Region": "Kabupaten Majene",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Barat",
   "Region": "Kabupaten Mamasa",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Barat",
   "Region": "Kabupaten Mamuju",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Barat",
   "Region": "Kabupaten Mamuju Tengah",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Barat",
   "Region": "Kabupaten Pasangkayu",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Sulawesi",
   "Provinsi": "Sulawesi Barat",
   "Region": "Kabupaten Polewali Mandar",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Halmahera Barat",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Halmahera Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Halmahera Tengah",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Halmahera Timur",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Halmahera Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Kepulauan Sula",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Pulau Morotai",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kabupaten Pulau Taliabu",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kota Ternate",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Maluku",
   "Provinsi": "Maluku Utara",
   "Region": "Kota Tidore Kepulauan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Biak Numfor",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Jayapura",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Keerom",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Kepulauan Yapen",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Mamberamo Raya",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Sarmi",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Supiori",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kabupaten Waropen",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua",
   "Region": "Kota Jayapura",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat",
   "Region": "Kabupaten Fakfak",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat",
   "Region": "Kabupaten Kaimana",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat",
   "Region": "Kabupaten Manokwari",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat",
   "Region": "Kabupaten Manokwari Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat",
   "Region": "Kabupaten Pegunungan Arfak",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat",
   "Region": "Kabupaten Teluk Bintuni",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat",
   "Region": "Kabupaten Teluk Wondama",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Selatan",
   "Region": "Kabupaten Asmat",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Selatan",
   "Region": "Kabupaten Boven Digoel",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Selatan",
   "Region": "Kabupaten Mappi",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Selatan",
   "Region": "Kabupaten Merauke",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Deiyai",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Dogiyai",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Intan Jaya",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Mimika",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Nabire",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Paniai",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Puncak",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Tengah",
   "Region": "Kabupaten Puncak Jaya",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Jayawijaya",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Lanny Jaya",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Mamberamo Tengah",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Nduga",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Pegunungan Bintang",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Tolikara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Yalimo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Pegunungan",
   "Region": "Kabupaten Yahukimo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat Daya",
   "Region": "Kabupaten Maybrat",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat Daya",
   "Region": "Kabupaten Raja Ampat",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat Daya",
   "Region": "Kabupaten Sorong",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat Daya",
   "Region": "Kabupaten Sorong Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat Daya",
   "Region": "Kabupaten Tambrauw",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Papua",
   "Provinsi": "Papua Barat Daya",
   "Region": "Kota Sorong",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Bima",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Dompu",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Lombok Barat",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Lombok Tengah",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Lombok Timur",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Lombok Utara",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Sumbawa",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kabupaten Sumbawa Barat",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kota Bima",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Barat",
   "Region": "Kota Mataram",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Alor",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Belu",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Ende",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Flores Timur",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Kupang",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Lembata",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Malaka",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Manggarai",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Manggarai Barat",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Manggarai Timur",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Nagekeo",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Ngada",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Rote Ndao",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Sabu Raijua",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Sikka",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Sumba Barat",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Sumba Barat Daya",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Sumba Tengah",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Sumba Timur",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Timor Tengah Selatan",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kabupaten Timor Tengah Utara",
   "Branch": "Branch Makassar"
 },
 {
   "Regional": "Nusa Tenggara",
   "Provinsi": "Nusa Tenggara Timur",
   "Region": "Kota Kupang",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Bantul",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Gunungkidul",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Kulon Progo",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kabupaten Sleman",
   "Branch": "Branch Surabaya"
 },
 {
   "Regional": "Jawa",
   "Provinsi": "DI Yogyakarta",
   "Region": "Kota Yogyakarta",
   "Branch": "Branch Surabaya"
 }
]';