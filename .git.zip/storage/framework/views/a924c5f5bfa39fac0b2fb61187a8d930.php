<?php $__env->startSection('content'); ?>
<div class="container min-vh-100 d-flex align-items-center justify-content-center">
    <div class="row justify-content-center w-100">
        <div class="col-xl-10 col-lg-12 col-md-9">
            <div class="card o-hidden border-0 shadow-lg">
                <div class="card-body p-0">
                    <div class="row">
                        <!-- Logo -->
                        <div class="col-lg-6 d-none d-lg-flex align-items-center justify-content-center bg-white">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid p-4" style="max-height: 200px;" alt="Logo Daxtro">
                        </div>

                        <!-- Login Form -->
                        <div class="col-lg-6">
                            <div class="p-5">
                                <div class="text-center mb-4">
                                    <h1 class="h4 text-gray-900">DAXTRO</h1>
                                </div>

                                <form class="user" method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input type="email" name="email" class="form-control form-control-user" id="email" placeholder="Enter Email Address..." required autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="password" class="form-control form-control-user" id="password" placeholder="Password" required>
                                    </div>
                                    <button type="submit" style="background:#115641;" class="btn btn-primary btn-user btn-block">Login</button>
                                </form>

                                <hr>
                                <div class="text-center">
                                    <a class="small" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                                </div>
                            </div>
                        </div>
                        <!-- End Login Form -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if(session('success')): ?>
<script>
    $(document).ready(function () {
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: <?php echo json_encode(session('success'), 15, 512) ?>
        });
    });
</script>
<?php endif; ?>
<?php if($errors->has('email')): ?>
<script>
    $(document).ready(function () {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: <?php echo json_encode($errors->first('email'), 15, 512) ?>
        });
    });
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Desktop\Sasha\Kuliah\ERP\sys.daxtro.com\resources\views/auth/login.blade.php ENDPATH**/ ?>