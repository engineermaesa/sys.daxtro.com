<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="card mb-4">
            <div class="card-body">
                <?php if($quotation->status === 'rejected' && isset($rejection)): ?>
                    <div class="alert alert-danger">
                        Quotation rejected by <b><?php echo e($rejection->reviewer->name ?? $rejection->role); ?></b> on
                        <?php echo e($rejection->decided_at ? \Carbon\Carbon::parse($rejection->decided_at)->format('d M Y') : ''); ?>

                        <strong>Notes:</strong> <?php echo e($rejection->notes); ?>

                    </div>
                <?php elseif($quotation->status === 'review'): ?>
                    <?php
                        $roleCode = auth()->user()->role?->code;
                    ?>

                    <?php
                        $bmReview = $quotation->reviews->where('role', 'BM')->sortByDesc('decided_at')->first();
                        $dirReview = $quotation->reviews
                            ->where('role', 'SD')
                            ->sortByDesc('decided_at')
                            ->first();
                    ?>
                    <div class="alert alert-warning">
                        This quotation is currently under review.<br>
                        Branch Manager: <strong><?php echo e($bmReview ? ucfirst($bmReview->decision) : 'Pending'); ?></strong><br>
                        Sales Director: <strong><?php echo e($dirReview ? ucfirst($dirReview->decision) : 'Pending'); ?></strong><br>
                        <?php if(in_array($roleCode, ['branch_manager', 'sales_director']) &&
                                !(($roleCode === 'branch_manager' && $bmReview) ||
                                  ($roleCode === 'sales_director' && $dirReview)) &&
                                !($roleCode === 'sales_director' && !$bmReview)): ?>
                            You can <strong>approve</strong> or <strong>reject</strong> this quotation using the buttons in
                            the bottom of the page.
                        <?php else: ?>
                            Please wait for approval from Branch Manager then Sales Director.
                        <?php endif; ?>
                    </div>
                <?php elseif($quotation && $quotation->status === 'published' && $quotation->reviews->count()): ?>
                    <?php
                        $approval = $quotation->reviews
                            ->where('decision', 'approve')
                            ->sortByDesc('decided_at')
                            ->first();
                    ?>
                    <?php if($approval): ?>
                        <div class="alert alert-success">
                            Quotation published on
                            <?php echo e($approval->decided_at ? \Carbon\Carbon::parse($approval->decided_at)->format('d M Y H:i:s') : '-'); ?>

                            WIB<br>
                            <strong>Notes:</strong> <?php echo e($approval->notes); ?>

                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <h5>Quotation Detail</h5>
                <table class="table table-sm">
                    <tr>
                        <th>No</th>
                        <td><?php echo e($quotation->quotation_no); ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            <?php
                                $statusClass =
                                    [
                                        'draft' => 'secondary',
                                        'review' => 'warning',
                                        'published' => 'success',
                                        'rejected' => 'danger',
                                    ][$quotation->status] ?? 'light';
                            ?>
                            <span class="badge bg-<?php echo e($statusClass); ?>"><?php echo e(ucfirst($quotation->status)); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th>Customer</th>
                        <td><?php echo e($quotation->lead->name ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Sub Total</th>
                        <td>Rp<?php echo e(number_format($quotation->subtotal, 0, ',', '.')); ?></td>
                    </tr>
                    <tr>
                        <th>Tax (<?php echo e($quotation->tax_pct); ?>%)</th>
                        <td>Rp<?php echo e(number_format($quotation->tax_total, 0, ',', '.')); ?></td>
                    </tr>
                    <?php if(!empty($quotation->discount)): ?>
                        <tr>
                            <th>Discount</th>
                            <td class="text-danger">- Rp<?php echo e(number_format($quotation->discount, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <th>Grand Total</th>
                        <td class="fw-bold">Rp<?php echo e(number_format($quotation->grand_total, 0, ',', '.')); ?></td>
                    </tr>
                    
                    <?php if(!empty($quotation->booking_fee)): ?>
                        <tr>
                            <th>Payment Type</th>
                            <td>Booking Fee | Rp<?php echo e(number_format($quotation->booking_fee, 0, ',', '.')); ?></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <th>Payment Type</th>
                            <td>Direct Down Payment</td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <th>Expiry Date</th>
                        <td class="fw-bold"><?php echo e($quotation->expiry_date ? date('d M Y', strtotime($quotation->expiry_date)) : '-'); ?></td>
                    </tr>
                </table>
                <h6 class="mt-4">Items</h6>
                <?php
                    $isSales = auth()->user()->role?->code === 'sales';
                    $orderId = $quotation->order->id ?? null;
                ?>


                <table class="table table-bordered table-sm">
                    <thead class="table-light">
                        <tr>
                            <th>Description</th>
                            <th>Qty</th>
                            <th>Unit Price</th>
                            <th>Disc %</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $quotation->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->description); ?></td>
                                <td><?php echo e($item->qty); ?></td>
                                <td>Rp<?php echo e(number_format($item->unit_price, 0, ',', '.')); ?></td>
                                <td><?php echo e($item->discount_pct); ?></td>
                                <td>Rp<?php echo e(number_format($item->line_total, 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="4" class="text-end">Sub Total</th>
                            <th class="text-end">Rp<?php echo e(number_format($quotation->subtotal, 0, ',', '.')); ?></th>
                        </tr>
                        <tr>
                            <th colspan="4" class="text-end">Tax (<?php echo e($quotation->tax_pct); ?>%)</th>
                            <th class="text-end">Rp<?php echo e(number_format($quotation->tax_total, 0, ',', '.')); ?></th>
                        </tr>
                        <?php if(!empty($quotation->discount)): ?>
                            <tr>
                                <th colspan="4" class="text-end">Discount</th>
                                <th class="text-end text-danger">- Rp<?php echo e(number_format($quotation->discount, 0, ',', '.')); ?>

                                </th>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th colspan="4" class="text-end">Grand Total</th>
                            <th class="text-end fw-bold">Rp<?php echo e(number_format($quotation->grand_total, 0, ',', '.')); ?></th>
                        </tr>
                    </tfoot>
                </table>


                <h6 class="mt-4">Payment Terms</h6>
                <table class="table table-bordered table-sm">
                    <thead class="table-light">
                        <tr>
                            <th>Term</th>
                            <th>Percentage</th>
                            <th>Total (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $quotation->paymentTerms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($term->term_no); ?></td>
                                <td><?php echo e($term->percentage); ?>%</td>
                                <td>
                                    Rp<?php echo e(number_format(($quotation->grand_total * $term->percentage) / 100, 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php if($quotation->proformas->count()): ?>
                    <h6 class="mt-4">Proformas</h6>
                    <table class="table table-bordered table-sm">
                        <thead class="table-light">
                            <tr>
                                <th>Term</th>
                                <th>No</th>
                                <th>Status</th>
                                <th>Issued</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $quotation->proformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pf->term_no ?? 'Booking Fee'); ?></td>
                                    <td><?php echo e($pf->proforma_no ?? '-'); ?></td>
                                    <td><?php echo e(ucfirst($pf->status)); ?></td>
                                    <td><?php echo e($pf->issued_at ? date('d M Y', strtotime($pf->issued_at)) : '-'); ?></td>
                                    <td>Rp<?php echo e(number_format($pf->amount, 0, ',', '.')); ?>


                                        <?php if($pf->paymentConfirmation): ?>
                                            <?php $fr = $pf->paymentConfirmation->financeRequest; ?>
                                            <?php if($fr && in_array($fr->status, ['approved','rejected'])): ?>
                                                <div class="small text-<?php echo e($fr->status === 'approved' ? 'success' : 'danger'); ?> mt-1">
                                                    <?php echo e(ucfirst($fr->status)); ?>: <?php echo e($fr->notes); ?>

                                                </div>
                                            <?php elseif($fr): ?>
                                                <div class="small text-warning mt-1">Awaiting Finance</div>
                                            <?php endif; ?>
                                            <?php if($fr && $fr->status !== 'rejected'): ?>
                                                <div class="small text-success mt-1">
                                                    Paid at: <?php echo e($pf->paymentConfirmation->paid_at->format('d M Y')); ?><br>
                                                    Confirmed by: <?php echo e($pf->paymentConfirmation->confirmedBy?->name ?? '-'); ?>

                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($pf->attachment_id): ?>
                                            <a href="<?php echo e(route('attachments.download', $pf->attachment_id)); ?>"
                                                class="btn btn-sm btn-outline-secondary">
                                                <i class="bi bi-download"></i> Download Proforma
                                            </a>

                                            <?php if($pf->invoice && $pf->invoice->attachment_id): ?>
                                                <a href="<?php echo e(route('attachments.download', $pf->invoice->attachment_id)); ?>"
                                                    class="btn btn-sm btn-outline-secondary ms-1">
                                                    <i class="bi bi-download"></i> Download Invoice
                                                </a>
                                            <?php endif; ?>

                                            <?php if($pf->status === 'confirmed'): ?>
                                                <?php $fr = $pf->paymentConfirmation?->financeRequest; ?>
                                                <?php if(!$pf->paymentConfirmation && $isSales): ?>
                                                    <a href="<?php echo e(route('payment-confirmation.terms.payment.confirm.form', [$quotation->lead_id, $pf->term_no ?? 'bf'])); ?>"
                                                        class="btn btn-sm btn-outline-primary ml-1">
                                                        <i class="bi bi-cash-coin"></i> Confirm Payment
                                                    </a>
                                                <?php endif; ?>

                                                <?php if($pf->paymentConfirmation): ?>
                                                    <a href="<?php echo e(route('payment-confirmation.terms.payment.confirm.form', [$quotation->lead_id, $pf->term_no ?? 'bf'])); ?>"
                                                        class="btn btn-sm <?php echo e($fr && $fr->status === 'rejected' ? 'btn-outline-danger' : 'btn-outline-success'); ?> ml-1">
                                                        <i
                                                            class="bi <?php echo e($fr && $fr->status === 'rejected' ? 'bi-pencil-square' : 'bi-eye'); ?>"></i>
                                                        <?php echo e($fr && $fr->status === 'rejected' ? 'Edit Payment' : 'View Payment'); ?>

                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <?php if($quotation->signedDocuments->count()): ?>
                    <h6 class="mt-4">Signed Documents</h6>
                    <table class="table table-bordered table-sm">
                        <thead class="table-light">
                            <tr>
                                <th>File</th>
                                <th>Description</th>
                                <th>Signed Date</th>
                                <th>Uploaded By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $quotation->signedDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('attachments.download', $doc->attachment_id)); ?>" class="btn btn-sm btn-outline-secondary">
                                            <i class="bi bi-download"></i> <?php echo e(basename($doc->attachment?->file_path ?? '')); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($doc->description); ?></td>
                                    <td><?php echo e($doc->signed_date ? date('d M Y', strtotime($doc->signed_date)) : '-'); ?></td>
                                    <td><?php echo e($doc->uploader?->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <?php if($quotation->paymentLogs->count()): ?>
                    <h6 class="mt-4">Payment Logs</h6>
                    <table class="table table-bordered table-sm">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Detail</th>
                                <th>User</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $quotation->paymentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log->logged_at ? \Carbon\Carbon::parse($log->logged_at)->format('d M Y H:i') : '-'); ?></td>
                                    <td><?php echo e(ucfirst($log->type)); ?></td>
                                    <td>
                                        <?php if($log->type === 'proforma'): ?>
                                            <?php echo e($log->proforma?->proforma_no); ?>

                                        <?php elseif($log->type === 'invoice'): ?>
                                            <?php echo e($log->invoice?->invoice_no); ?>

                                        <?php elseif($log->type === 'confirmation'): ?>
                                            <?php echo e($log->proforma?->term_no ? 'Term ' . $log->proforma->term_no : 'Booking Fee'); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($log->user->name ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <?php if(auth()->user()->role?->code === 'sales' && isset($claim)): ?>
                    <h6 class="mt-4">Upload Signed Document</h6>
                    <form action="<?php echo e(route('quotations.signed-documents.upload', $quotation->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="signed_file" class="form-label">Signed File <i class="required">*</i></label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="signed_file" name="file" accept=".pdf,.jpg,.jpeg,.png" required>
                                <label class="custom-file-label" for="signed_file">Choose file...</label>
                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="signed_date" class="form-label">Signed Date <i class="required">*</i></label>
                            <input type="date" name="signed_date" id="signed_date" class="form-control form-control-sm <?php $__errorArgs = ['signed_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required value="<?php echo e(old('signed_date')); ?>" onfocus="this.showPicker()">
                            <?php $__errorArgs = ['signed_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <input type="text" name="description" id="description" class="form-control form-control-sm" value="<?php echo e(old('description')); ?>">
                        </div>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-primary">Upload</button>
                        </div>
                    </form>
                <?php endif; ?>

                <div class="d-flex justify-content-between mt-4">
                    <div>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-light">Back</a>
                        <a href="<?php echo e(route('quotations.download', $quotation->id)); ?>" class="btn btn-outline-secondary ms-2">
                            <i class="bi bi-download"></i> Download Quotation
                        </a>
                        <?php
                            $userRole   = auth()->user()->role?->code;
                            $bmApproved = $quotation->reviews->where('role', 'BM')->where('decision', 'approve')->isNotEmpty();
                            $dirApproved = $quotation->reviews->where('role', 'SD')->where('decision', 'approve')->isNotEmpty();
                            $allApproved = $bmApproved && $dirApproved;
                            $hasPayment = $quotation->proformas->contains(function ($p) {
                                return $p->paymentConfirmation !== null;
                            });

                            if (! $allApproved) {
                                $canEdit = $userRole === 'sales' && isset($claim);
                            } else {
                                $canEdit = in_array($userRole, ['branch_manager', 'sales_director']) && ! $hasPayment;
                            }
                        ?>
                        <?php if($canEdit && $claim): ?>
                            <a href="<?php echo e(route('leads.my.warm.quotation.create', $claim->id)); ?>" class="btn btn-primary ms-2">Edit Quotation</a>
                        <?php endif; ?>
                    </div>
                    <?php
                        $userRole   = auth()->user()->role?->code;
                        $bmApproved = $quotation->reviews
                            ->where('role', 'BM')
                            ->where('decision', 'approve')
                            ->isNotEmpty();
                        $reviewed = $userRole === 'branch_manager'
                            ? $quotation->reviews->where('role', 'BM')->isNotEmpty()
                            : ($userRole === 'sales_director' ? $quotation->reviews->where('role', 'SD')->isNotEmpty() : false);
                        $canReview = ($userRole === 'branch_manager' && !$reviewed) ||
                            ($userRole === 'sales_director' && $bmApproved && !$reviewed);
                    ?>
                    <?php if($quotation->status === 'review' && $canReview): ?>
                        <div class="d-flex flex-column align-items-end" style="gap: 0.5rem;">
                            <div class="d-flex align-items-end" style="gap: 0.5rem;">
                                <form method="POST" id="approve"
                                    action="<?php echo e(route('quotations.approve', $quotation->id)); ?>" require-confirmation="true"
                                    class="d-flex align-items-end" style="gap: 0.5rem;">
                                    <?php echo csrf_field(); ?>
                                    <textarea name="notes" class="form-control form-control-sm" rows="1" placeholder="Enter notes..." required style="min-width: 220px;"></textarea>
                                    <button class="btn btn-success">Approve</button>
                                </form>

                                <form method="POST" id="reject"
                                    action="<?php echo e(route('quotations.reject', $quotation->id)); ?>" require-confirmation="true"
                                    class="d-flex align-items-end" style="gap: 0.5rem;">
                                    <?php echo csrf_field(); ?>
                                    <textarea name="notes" class="form-control form-control-sm" rows="1" placeholder="Enter notes..." required style="min-width: 220px;"></textarea>
                                    <button class="btn btn-danger">Reject</button>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const observer = new MutationObserver(() => {
            const confirmBtn = document.querySelector('.swal2-confirm');
            if (confirmBtn && !confirmBtn.dataset.bound) {
                confirmBtn.dataset.bound = 'true';
                confirmBtn.addEventListener('click', function() {
                    if (typeof loading === 'function') loading();
                });
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        const fileInput = document.getElementById('signed_file');
        if (fileInput) {
            fileInput.addEventListener('change', function(e) {
                const name = e.target.files[0] ? e.target.files[0].name : 'Choose file...';
                e.target.nextElementSibling.innerText = name;
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Desktop\Sasha\Kuliah\ERP\sys.daxtro.com\resources\views/pages/orders/quotation-show.blade.php ENDPATH**/ ?>