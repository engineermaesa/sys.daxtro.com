<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DAXTRO</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('sb-admin-2/vendor/fontawesome-free/css/all.min.css')); ?>?ver=1.0.4" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('sb-admin-2/css/sb-admin-2.min.css')); ?>?ver=1.0.4" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/summernote-bs5.min.css')); ?>?ver=1.0.4" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/datatables.min.css')); ?>?ver=1.0.4" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/select2.min.css')); ?>?ver=1.0.4">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/notfy.min.css')); ?>?ver=1.0.4">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/sweetalert2.min.css')); ?>?ver=1.0.4">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/main.css')); ?>?ver=1.0.4">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body id="page-top">
	<div id="loader" class="loader hidden"></div>
    <div id="wrapper">
        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('sb-admin-2/vendor/jquery/jquery.min.js')); ?>?ver=1.0.4"></script>
    <script src="<?php echo e(asset('sb-admin-2/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>?ver=1.0.4"></script>
    <script src="<?php echo e(asset('sb-admin-2/vendor/jquery-easing/jquery.easing.min.js')); ?>?ver=1.0.4"></script>
    <script src="<?php echo e(asset('sb-admin-2/js/sb-admin-2.min.js')); ?>?ver=1.0.4"></script>
	<script src="<?php echo e(asset('assets/js/datatables.min.js')); ?>?ver=1.0.4"></script>
	<script src="<?php echo e(asset('assets/js/select2.min.js')); ?>?ver=1.0.4"></script>
	<script src="<?php echo e(asset('assets/js/notyf.min.js')); ?>?ver=1.0.4"></script>
    <script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>?ver=1.0.4"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>?ver=1.0.4"></script>
    <script>
        var notyf = new Notyf({
            position: {
            x: 'right',
            y: 'top',
            }
        });
        
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Asus\OneDrive\Desktop\Sasha\Kuliah\ERP\sys.daxtro.com\resources\views/layouts/app.blade.php ENDPATH**/ ?>