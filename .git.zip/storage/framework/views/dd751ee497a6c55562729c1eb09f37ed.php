<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="card mb-4">
    <div class="card-header">
      <strong>Finance Request Detail</strong>
    </div>
    <div class="card-body">
      <?php if(session('error')): ?>
        <div class="alert alert-danger">
          <?php echo e(session('error')); ?>

        </div>
      <?php endif; ?>

      <?php if(session('status')): ?>
        <div class="alert alert-success">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>

      <?php
        $typeColors = [
          'proforma' => 'primary',
          'invoice' => 'success',
          'payment-confirmation' => 'warning',
          'meeting-expense' => 'info',
        ];
        $statusColors = [
          'pending' => 'warning',
          'approved' => 'success',
          'rejected' => 'danger',
        ];
      ?>
      <table class="table table-sm">
        <tr><th>Type</th><td><span class="badge bg-<?php echo e($typeColors[$financeRequest->request_type] ?? 'secondary'); ?>"><?php echo e(ucwords(str_replace('-', ' ', $financeRequest->request_type))); ?></span></td></tr>
        <tr><th>Status</th><td><span class="badge bg-<?php echo e($statusColors[$financeRequest->status] ?? 'secondary'); ?>"><?php echo e(ucwords(str_replace('-', ' ', $financeRequest->status))); ?></span></td></tr>
        <tr><th>Requester</th><td><?php echo e($financeRequest->requester->name ?? '-'); ?></td></tr>        
        <tr><th>Requested At</th><td><?php echo e(date('d M Y, H:i', strtotime($financeRequest->created_at))); ?></td></tr>
        <tr><th>Decided At</th><td><?php echo e($financeRequest->decided_at ? date('d M Y, H:i', strtotime($financeRequest->decided_at)) : '-'); ?></td></tr>
        <tr><th>Notes</th><td><?php echo e($financeRequest->notes); ?></td></tr>
      </table>
    </div>
  </div>

  <?php if($order): ?>
  <div class="card mb-4">
    <div class="card-header">
      <strong>Order Information</strong>
    </div>
    <div class="card-body">
      <table class="table table-sm">
        <tr><th>Order No</th><td><?php echo e($order->order_no); ?></td></tr>
        <tr><th>Customer</th><td><?php echo e($order->lead->name ?? '-'); ?></td></tr>
        <tr><th>Total Billing</th><td><?php echo e($order->total_billing); ?></td></tr>
        <tr><th>Status</th><td><?php echo e($order->order_status); ?></td></tr>
      </table>

      <h6>Items</h6>
      <table class="table table-bordered table-sm">
        <thead class="table-light">
          <tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $order->orderItems ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->description); ?></td>
            <td><?php echo e($item->qty); ?></td>
            <td><?php echo e($item->unit_price); ?></td>
            <td><?php echo e($item->line_total); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <h6>Payment Terms</h6>
      <table class="table table-bordered table-sm">
        <thead class="table-light">
          <tr><th>Term</th><th>Percentage</th></tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $order->paymentTerms ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($term->term_no); ?></td>
            <td><?php echo e($term->percentage); ?>%</td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

  <?php if($proforma): ?>
  <div class="card mb-4">
    <div class="card-header">
      <strong>Proforma Information</strong>
    </div>
    <div class="card-body">
      <table class="table table-sm">
        <tr><th>Proforma No</th><td><?php echo e($proforma->proforma_no); ?></td></tr>
        <tr><th>Term</th><td><b><?php echo e($proforma->term_no ?? 'Booking Fee'); ?></b></td></tr>
        <tr><th>Status</th><td><?php echo e(ucfirst($proforma->status)); ?></td></tr>
        <tr><th>Amount</th><td>Rp<?php echo e(number_format($proforma->amount, 0, ',', '.')); ?></td></tr>
      </table>

      <h6>Quotation Detail</h6>
      <table class="table table-bordered table-sm">
        <thead class="table-light">
          <tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $proforma->quotation->order->orderItems ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($item->description); ?></td>
            <td><?php echo e($item->qty); ?></td>
            <td><?php echo e($item->unit_price); ?></td>
            <td><?php echo e($item->line_total); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <?php if($proforma->paymentConfirmation): ?>
      <h6 class="mt-3">Payment Confirmation Details</h6>
      <table class="table table-bordered table-sm">
        <tr><th>Payer Name</th><td><?php echo e($proforma->paymentConfirmation->payer_name); ?></td></tr>
        <tr><th>Payer Bank</th><td><?php echo e($proforma->paymentConfirmation->payer_bank); ?></td></tr>
        <tr><th>Account Number</th><td><?php echo e($proforma->paymentConfirmation->payer_account_number); ?></td></tr>
        <tr><th>Paid At</th><td><?php echo e($proforma->paymentConfirmation->paid_at?->format('d M Y')); ?></td></tr>
        <tr><th>Amount</th><td>Rp<?php echo e(number_format($proforma->paymentConfirmation->amount, 0, ',', '.')); ?></td></tr>
        <tr><th>Evidence</th><td>
          <?php if($proforma->paymentConfirmation->attachment): ?>
            <a href="<?php echo e(route('attachments.download', $proforma->paymentConfirmation->attachment_id)); ?>" class="btn btn-sm btn-outline-secondary">Download</a>
          <?php endif; ?>
        </td></tr>
      </table>
      <?php endif; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if(isset($proforma) && $proforma->invoice && $proforma->invoice->attachment_id): ?>
    <h6 class="mt-3">Invoice</h6>
    <table class="table table-bordered table-sm">
      <tr><th>Invoice No</th><td><?php echo e($proforma->invoice->invoice_no); ?></td></tr>
      <tr><th>Issued At</th><td><?php echo e(\Carbon\Carbon::parse($proforma->invoice->issued_at)->format('d M Y')); ?></td></tr>
      <tr><th>Amount</th><td>Rp<?php echo e(number_format($proforma->invoice->amount, 0, ',', '.')); ?></td></tr>
      <tr><th>Download</th>
        <td>
          <a href="<?php echo e(route('attachments.download', $proforma->invoice->attachment_id)); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-download"></i> Download Invoice
          </a>
        </td>
      </tr>
    </table>
  <?php endif; ?>


  <?php if($meetingExpense): ?>
    <div class="card mb-4">
      <div class="card-header">
        <strong>Meeting Expense Details</strong>
      </div>
      <div class="card-body">
        <table class="table table-sm">
          <tr><th>Lead</th><td><?php echo e($meetingExpense->meeting->lead->name ?? '-'); ?></td></tr>
          <tr><th>Meeting Date</th><td><?php echo e(\Carbon\Carbon::parse($meetingExpense->meeting->scheduled_start_at)->format('d M Y H:i')); ?></td></tr>
          <tr><th>Total Amount</th><td>Rp<?php echo e(number_format($meetingExpense->amount, 0, ',', '.')); ?></td></tr>
          <tr><th>Status</th><td><span class="badge badge-<?php echo e($meetingExpense->status === 'approved' ? 'success' : ($meetingExpense->status === 'rejected' ? 'danger' : 'warning')); ?>"><?php echo e(ucfirst($meetingExpense->status)); ?></span></td></tr>
        </table>

        <h6>Expense Breakdown</h6>
        <table class="table table-bordered table-sm">
          <thead class="table-light">
            <tr>
              <th>Type</th>
              <th>Notes</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $meetingExpense->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($detail->expenseType->name ?? '-'); ?></td>
              <td><?php echo e($detail->notes ?? '-'); ?></td>
              <td>Rp<?php echo e(number_format($detail->amount, 0, ',', '.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>

  <?php if($financeRequest->status === 'pending'): ?>
  <form method="POST" action="<?php echo e(route('finance-requests.approve', $financeRequest->id)); ?>" require-confirmation="true" class="mb-3">
    <?php echo csrf_field(); ?>
    <div class="mb-2">
      <textarea name="notes" class="form-control" placeholder="Notes" required></textarea>
    </div>
    <div class="text-end">
      <button class="btn btn-primary">Approve</button>
    </div>
  </form>
  <form method="POST" action="<?php echo e(route('finance-requests.reject', $financeRequest->id)); ?>" require-confirmation="true">
    <?php echo csrf_field(); ?>
    <div class="mb-2">
      <textarea name="notes" class="form-control" placeholder="Notes" required></textarea>
    </div>
    <div class="text-end">
      <button class="btn btn-danger">Reject</button>
    </div>
  </form>
  <div class="text-end mt-2">
    <a href="<?php echo e(route('finance-requests.index')); ?>" class="btn btn-secondary">Back</a>
  </div>
  <?php endif; ?>

  <?php if($financeRequest->status !== 'pending'): ?>
  <div class="text-end">
    <a href="<?php echo e(route('finance-requests.index')); ?>" class="btn btn-secondary me-2">Back</a>
  </div>
  <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Desktop\Sasha\Kuliah\ERP\sys.daxtro.com\resources\views/pages/finance/requests/form.blade.php ENDPATH**/ ?>