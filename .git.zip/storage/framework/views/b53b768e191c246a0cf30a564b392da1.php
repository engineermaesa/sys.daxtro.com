<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
        <div class="sidebar-brand-icon">
            <img src="<?php echo e(asset('assets/images/favicon.png')); ?>" alt="DAXTRO Logo" style="max-height: 40px;">
        </div>
        <div class="sidebar-brand-text mx-3">DAXTRO</div>
    </a>
    <hr class="sidebar-divider my-0">

    <?php if(auth()->check() && auth()->user()->hasPermission('dashboard')): ?>
    <li class="nav-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    <?php endif; ?>

    <hr class="sidebar-divider">    

    <?php
        $showLeads = auth()->check() && (
            auth()->user()->hasPermission('leads.manage') ||
            auth()->user()->hasPermission('leads.available') ||
            auth()->user()->hasPermission('leads.my') ||
            auth()->user()->hasPermission('leads.trash')
        );
    ?>
    <?php if($showLeads): ?>
    <li class="nav-item <?php echo e((request()->is('leads*') || request()->is('quotations*') || request()->is('payment-confirmation*') || request()->is('trash-leads*')) ? 'active' : ''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLeads" aria-expanded="<?php echo e((request()->is('leads*') || request()->is('quotations*') || request()->is('payment-confirmation*') || request()->is('trash-leads*')) ? 'true' : 'false'); ?>" aria-controls="collapseLeads">
            <i class="fas fa-fw fa-address-book"></i>
            <span>Leads</span>
        </a>
        <div id="collapseLeads" class="collapse <?php echo e((request()->is('leads*') || request()->is('quotations*') || request()->is('payment-confirmation*') || request()->is('trash-leads*')) ? 'show' : ''); ?>" aria-labelledby="headingLeads" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <?php if(auth()->check() && (auth()->user()->hasPermission('leads.available') || auth()->user()->hasPermission('leads.available'))): ?>
                <a class="collapse-item <?php echo e(request()->is('leads/available*') ? 'active' : ''); ?>" href="<?php echo e(route('leads.available')); ?>">Available Leads</a>
                <?php endif; ?>
                <?php if(auth()->check() && (auth()->user()->hasPermission('leads.my') || auth()->user()->hasPermission('leads.my'))): ?>
                <a class="collapse-item <?php echo e(request()->is('leads/my*') || request()->is('quotations*') || request()->is('payment-confirmation*') ? 'active' : ''); ?>" href="<?php echo e(route('leads.my')); ?>">My Leads</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('leads.manage')): ?>
                <a class="collapse-item <?php echo e(request()->is('leads/manage*') || request()->is('quotations*') || request()->is('payment-confirmation*') ? 'active' : ''); ?>" href="<?php echo e(route('leads.manage')); ?>">All Leads</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->role?->code === 'super_admin'): ?>
                <a class="collapse-item <?php echo e(request()->is('leads/import*') ? 'active' : ''); ?>" href="<?php echo e(route('leads.import')); ?>">Import Leads</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('leads.trash')): ?>
                <a class="collapse-item <?php echo e(request()->is('trash-leads*') ? 'active' : ''); ?>" href="<?php echo e(route('trash-leads.index')); ?>">Trash Leads</a>
                <?php endif; ?>
            </div>
        </div>
    </li>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasPermission('orders')): ?>
    <li class="nav-item <?php echo e(request()->routeIs('orders*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('orders.index')); ?>">
            <i class="fas fa-fw fa-shopping-cart"></i>
            <span>Orders</span>
        </a>
    </li>
    <?php endif; ?>

    
    <?php if(auth()->check() && auth()->user()->hasPermission('finance.requests')): ?>
    <li class="nav-item <?php echo e(request()->routeIs('finance-requests.*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('finance-requests.index')); ?>">
            <i class="fas fa-fw fa-file-invoice-dollar"></i>
            <span>Finance Requests</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if(auth()->check() && auth()->user()->hasPermission('incentives.view')): ?>
    <li class="nav-item <?php echo e(request()->routeIs('incentives.dashboard') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('incentives.dashboard')); ?>">
            <i class="fas fa-fw fa-gift"></i>
            <span>Incentives</span>
        </a>
    </li>
    <?php endif; ?>

    <?php
        $masterPermissions = [
            'masters.companies',
            'masters.provinces',
            'masters.branches',
            'masters.regions',
            'masters.banks',
            'masters.accounts',
            'masters.product-categories',
            'masters.products',
            'masters.parts',
            'masters.expense-types',
            'masters.customer-types',
        ];
        $showMasters = collect($masterPermissions)->contains(fn($p) => auth()->check() && auth()->user()->hasPermission($p));
    ?>
    <?php if($showMasters): ?>
    <li class="nav-item <?php echo e(request()->is('masters/*') ? 'active' : ''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMasters" aria-expanded="<?php echo e(request()->is('masters/*') ? 'true' : 'false'); ?>" aria-controls="collapseMasters">
            <i class="fas fa-fw fa-cog"></i>
            <span>Masters</span>
        </a>
        <div id="collapseMasters" class="collapse <?php echo e(request()->is('masters/*') ? 'show' : ''); ?>" aria-labelledby="headingMasters" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.companies')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.companies*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.companies.index')); ?>">Companies</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.provinces')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.provinces*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.provinces.index')); ?>">Provinces</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.branches')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.branches*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.branches.index')); ?>">Branches</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.regions')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.regions*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.regions.index')); ?>">Regions</a>
                <?php endif; ?>
                
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.expense-types')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.expense-types*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.expense-types.index')); ?>">Expense Types</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.customer-types')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.customer-types*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.customer-types.index')); ?>">Customer Types</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.product-categories')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.product-categories*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.product-categories.index')); ?>">Product Categories</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.parts')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.parts*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.parts.index')); ?>">Product Parts</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('masters.products')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('masters.products*') ? 'active' : ''); ?>" href="<?php echo e(route('masters.products.index')); ?>">Products</a>
                <?php endif; ?>                                
            </div>
        </div>
    </li>
    <?php endif; ?>

    <?php
        $userMenu = [
            'users.manage',
            'users.roles',
        ];
        $showUsers = collect($userMenu)->contains(fn($p) => auth()->check() && auth()->user()->hasPermission($p));
        $settingsMenu = [            
            'settings.permissions-settings',
        ];
        $showSettings = collect($settingsMenu)->contains(fn($p) => auth()->check() && auth()->user()->hasPermission($p));
    ?>
    <?php if($showUsers): ?>
    <li class="nav-item <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUsers"
        aria-expanded="<?php echo e(request()->is('users*') ? 'true' : 'false'); ?>" aria-controls="collapseUsers">
            <i class="fas fa-fw fa-users"></i>
            <span>Users</span>
        </a>
        <div id="collapseUsers" class="collapse <?php echo e(request()->is('users*') ? 'show' : ''); ?>"
            aria-labelledby="headingUsers" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <?php if(auth()->check() && auth()->user()->hasPermission('users.manage')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('users.index') ||request()->routeIs('users.form') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">Manage Users</a>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasPermission('users.roles')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('users.roles*') ? 'active' : ''); ?>" href="<?php echo e(route('users.roles.index')); ?>">Roles</a>
                <?php endif; ?>                
            </div>
        </div>
    </li>
    <?php endif; ?>

    <?php if($showSettings): ?>
    <li class="nav-item <?php echo e((request()->routeIs('settings.permissions-settings*') || request()->routeIs('settings.permissions-settings*')) ? 'active' : ''); ?>">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSettings"
            aria-expanded="<?php echo e((request()->routeIs('settings.permissions-settings*') || request()->routeIs('settings.permissions-settings*')) ? 'true' : 'false'); ?>" aria-controls="collapseSettings">
            <i class="fas fa-fw fa-cogs"></i>
            <span>Settings</span>
        </a>
        <div id="collapseSettings" class="collapse <?php echo e((request()->routeIs('settings.permissions-settings*') || request()->routeIs('settings.permissions-settings*')) ? 'show' : ''); ?>" aria-labelledby="headingSettings" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">                
                <?php if(auth()->check() && auth()->user()->hasPermission('settings.permissions-settings')): ?>
                <a class="collapse-item <?php echo e(request()->routeIs('settings.permissions-settings*') ? 'active' : ''); ?>" href="<?php echo e(route('settings.permissions-settings.index')); ?>">Permissions Settings</a>
                <?php endif; ?>
                
            </div>
        </div>
    </li>
    <?php endif; ?>

    <hr class="sidebar-divider d-none d-md-block">
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul><?php /**PATH C:\Users\Asus\OneDrive\Desktop\Sasha\Kuliah\ERP\sys.daxtro.com\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>