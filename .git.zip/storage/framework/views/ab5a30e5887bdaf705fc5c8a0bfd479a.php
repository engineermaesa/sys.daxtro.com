<footer class="sticky-footer bg-white mt-5" style="padding:1rem 0;background:#115641!important;color:white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>&copy; DAXTRO <?php echo e(date('Y')); ?> | Made with ♥︎ by Langit Creative Solutions</span>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Asus\OneDrive\Desktop\Sasha\Kuliah\ERP\sys.daxtro.com\resources\views/partials/footer.blade.php ENDPATH**/ ?>