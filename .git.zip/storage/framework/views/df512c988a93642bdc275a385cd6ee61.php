<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="row">
    <div class="col-xl-6 offset-xl-3">
      <div class="card">
        <div class="card-header">
          <strong>Meeting Result</strong>
        </div>
        <div class="card-body pt-3">
          <form id="form"
            method="POST"
            action="<?php echo e(route('leads.my.cold.meeting.result.save', $data->id)); ?>"
            back-url="<?php echo e(route('leads.my')); ?>"
            enctype="multipart/form-data"
            require-confirmation="true">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
              <label for="result" class="form-label">Meeting Outcome <i class="required">*</i></label>
              <br>
              <select name="result" id="result" class="form-select w-100" required>
                <option value="">-- Select Outcome --</option>
                <option value="yes" <?php if(old('result', $data->result) === 'yes'): echo 'selected'; endif; ?>>Interested (Convert to Warm)</option>
                <option value="no" <?php if(old('result', $data->result) === 'no'): echo 'selected'; endif; ?>>Not Interested (Move to Trash Cold)</option>
                <option value="waiting" <?php if(old('result', $data->result) === 'waiting'): echo 'selected'; endif; ?>>Waiting (Consideration)</option>
              </select>
            </div>

            <div class="mb-3">
              <label for="summary" class="form-label">Meeting Summary <i class="required">*</i></label>
              <textarea name="summary" id="summary" class="form-control" rows="4" required><?php echo e(old('summary', $data->summary)); ?></textarea>
            </div>

            <div class="form-group" id="attachmentField" style="display: none;">
              <label for="attachment_id" class="form-label">Supporting Attachment <i class="required">*</i></label>
              <div class="custom-file">
                <input type="file" class="custom-file-input" id="attachment_id" name="attachment_id" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                <label class="custom-file-label" for="attachment_id">Choose file...</label>
              </div>
            </div>

            <div class="d-flex justify-content-between">
              <a href="<?php echo e(route('leads.my')); ?>" class="btn btn-secondary">Back</a>
              <button type="submit" class="btn btn-primary">Submit Result</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const resultSelect = document.getElementById('result');
    const attachmentField = document.getElementById('attachmentField');
    const attachmentInput = document.getElementById('attachment_id');

    function toggleAttachment(val) {
      if (val === 'yes') {
        attachmentField.style.display = 'block';
        attachmentInput.setAttribute('required', 'required');
      } else {
        attachmentField.style.display = 'none';
        attachmentInput.removeAttribute('required');
        attachmentInput.value = '';
        attachmentInput.nextElementSibling.innerText = 'Choose file...';
      }
    }

    toggleAttachment(resultSelect.value);
    resultSelect.addEventListener('change', function () {
      toggleAttachment(this.value);
    });

    attachmentInput.addEventListener('change', function () {
      const fileName = this.files[0] ? this.files[0].name : 'Choose file...';
      this.nextElementSibling.innerText = fileName;
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Asus\OneDrive\Desktop\Sasha\Kuliah\ERP\sys.daxtro.com\resources\views/pages/leads/cold/meeting-result.blade.php ENDPATH**/ ?>