<div class="text-end">
    <?php if($backUrl == 'back'): ?>
        <a href="javascript:history.back()" class="btn btn-secondary me-2">Cancel</a>
    <?php else: ?>
        <a href="<?php echo e($backUrl); ?>" class="btn btn-secondary me-2">Cancel</a>
    <?php endif; ?>
    
    <?php if( ! isset($no_save_btn) ||  ! $no_save_btn): ?>
        <button type="submit" class="btn btn-primary">Save</button>
    <?php endif; ?>
</div><?php /**PATH /usr/local/var/www/daxtro2-main/resources/views/partials/common/save-btn-form.blade.php ENDPATH**/ ?>