<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="row">
    <div class="col-md-6 mb-3">
      <div class="card h-100">
        <div class="card-header"><strong>Download Template</strong></div>
        <div class="card-body d-flex flex-column align-items-start">
          <a href="<?php echo e(route('leads.import.template')); ?>" class="btn btn-success mb-3">
            <i class="bi bi-download"></i> Download Template
          </a>
          <button class="btn btn-link p-0" type="button" data-toggle="collapse" data-target="#importHelp" aria-expanded="false">
            Need help?
          </button>
          <div id="importHelp" class="collapse mt-2">
            <div class="alert alert-info small mb-0">
              Required fields are marked with *. Date format for <code>published_at</code> should be YYYY-MM-DD.
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-6 mb-3">
      <div class="card h-100">
        <div class="card-header"><strong>Upload Leads File</strong></div>
        <div class="card-body">
          <form id="uploadForm" action="<?php echo e(route('leads.import.preview')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="custom-file mb-3">
              <input type="file" class="custom-file-input" id="importFile" name="import_file" accept=".xlsx,.csv" required>
              <label class="custom-file-label" for="importFile">Choose Excel/CSV file...</label>
            </div>
            <button type="submit" class="btn btn-primary">Preview Import</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <?php if(isset($rows)): ?>
  <div class="card mt-3">
    <form id="submitForm" method="POST" action="<?php echo e(route('leads.import.store')); ?>">
      <?php echo csrf_field(); ?>
      <div class="card-header d-flex justify-content-between align-items-center">
        <strong>Preview Results</strong>
        <button type="submit" class="btn btn-success" <?php echo e($hasError ? 'disabled' : ''); ?>>Submit Verified Leads</button>
      </div>
      <div class="card-body p-0">
      <div class="table-responsive">
        <table id="previewTable" class="table table-bordered table-sm mb-0">
          <thead class="thead-light">
            <tr>
              <th>#</th>
              <th>source_id*</th>
              <th>segment_id*</th>
              <th>region_id*</th>
              <th>lead_name</th>
              <th>lead_email</th>
              <th>lead_phone</th>
              <th>lead_needs</th>
              <th>nip_sales</th>
              <th>published_at</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="<?php echo e($row['error'] ? 'table-danger' : ''); ?>" data-index="<?php echo e($idx); ?>">
              <td><?php echo e($idx + 1); ?></td>
              <td>
                <select name="rows[<?php echo e($idx); ?>][source_id]" class="form-control form-control-sm">
                  <option value="">--</option>
                  <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php echo e($s->id == $row['source_id'] ? 'selected' : ''); ?>><?php echo e($s->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </td>
              <td>
                <select name="rows[<?php echo e($idx); ?>][segment_id]" class="form-control form-control-sm">
                  <option value="">--</option>
                  <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($seg->id); ?>" <?php echo e($seg->id == $row['segment_id'] ? 'selected' : ''); ?>><?php echo e($seg->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </td>
              <td>
                <select name="rows[<?php echo e($idx); ?>][region_id]" class="form-control form-control-sm">
                  <option value="">All Region</option>
                  <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($r->id); ?>" <?php echo e($r->id == $row['region_id'] ? 'selected' : ''); ?>><?php echo e($r->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </td>
              <td><input type="text" name="rows[<?php echo e($idx); ?>][lead_name]" value="<?php echo e($row['lead_name']); ?>" class="form-control form-control-sm"></td>
              <td><input type="text" name="rows[<?php echo e($idx); ?>][lead_email]" value="<?php echo e($row['lead_email']); ?>" class="form-control form-control-sm"></td>
              <td><input type="text" name="rows[<?php echo e($idx); ?>][lead_phone]" value="<?php echo e($row['lead_phone']); ?>" class="form-control form-control-sm"></td>
              <td><input type="text" name="rows[<?php echo e($idx); ?>][lead_needs]" value="<?php echo e($row['lead_needs']); ?>" class="form-control form-control-sm"></td>
              <td>
                <select name="rows[<?php echo e($idx); ?>][nip_sales]" class="form-control form-control-sm">
                  <option value="">--</option>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->nip); ?>" <?php echo e($u->nip == $row['nip_sales'] ? 'selected' : ''); ?>><?php echo e($u->nip); ?> - <?php echo e($u->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </td>
              <td><input type="text" name="rows[<?php echo e($idx); ?>][published_at]" value="<?php echo e($row['published_at']); ?>" class="form-control form-control-sm"></td>
              <td>
                <?php if($row['error']): ?>
                  <span class="badge badge-danger"><?php echo e($row['error']); ?></span>
                <?php else: ?>
                  <span class="badge badge-success">OK</span>
                <?php endif; ?>
              </td>
              <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-x"></i></button>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    </form>
  </div>
  <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php if(isset($rows)): ?>
<script>
$(function(){
  document.addEventListener('DOMContentLoaded', function () {
    bsCustomFileInput.init();

    $('#uploadForm').on('submit', function(){
      loading();
    });

    <?php if(session('success')): ?>
      notif('<?php echo e(session('success')); ?>');
    <?php endif; ?>
  });

  const table = $('#previewTable').DataTable({
    paging: true,
    searching: true,
    info: false,
    scrollX: true,
    fixedHeader: true
  });

  $('#previewTable').on('click', '.remove-row', function(){
    table.row($(this).closest('tr')).remove().draw();
  });

  $('#submitForm').on('submit', function(e){
    e.preventDefault();
    Swal.fire({
      title: 'Submit leads?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'Cancel'
    }).then(res => {
      if(res.isConfirmed){
        loading();
        this.submit();
      }
    });
  });
});
</script>
<?php endif; ?>
<script>
$('#uploadForm').on('submit', function(){
  loading();
});
<?php if(session('success')): ?>
  notif('<?php echo e(session('success')); ?>');
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /usr/local/var/www/daxtro2-main/resources/views/pages/leads/import.blade.php ENDPATH**/ ?>