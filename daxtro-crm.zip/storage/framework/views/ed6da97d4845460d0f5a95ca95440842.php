<div class="d-flex justify-content-end mb-2">
    <a href="<?php echo e($url); ?>" class="btn btn-sm btn-primary">
        <i class="bi bi-plus-circle me-1"></i> Add <?php echo e($title); ?>

    </a>
</div><?php /**PATH /usr/local/var/www/daxtro2-main/resources/views/partials/common/create-btn.blade.php ENDPATH**/ ?>