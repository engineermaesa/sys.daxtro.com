<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-xl-12">
                <div class="card mb-4">
                    <div class="card-body pt-3">
                        <div class="text-right">
                            <?php if(!empty($form_data->id) && $form_data->status_id == \App\Models\Leads\LeadStatus::PUBLISHED): ?>
                                <button type="button" class="btn btn-success me-2" id="btnClaim"
                                    data-url="<?php echo e(route('leads.claim', $form_data->id)); ?>">
                                    Claim Lead
                                </button>
                            <?php endif; ?>
                        </div>

                        <form method="POST" action="<?php echo e(route('leads.save', $form_data->id)); ?>" id="form"
                            back-url="<?php echo e(route('leads.available')); ?>" require-confirmation="true">
                            <?php echo csrf_field(); ?>
                            <?php $isCreate = empty($form_data->id); ?>

                            <div id="lead-entries">
                                <div class="lead-entry card mb-3">
                                    <?php if(empty($form_data->id)): ?>:
                                    <div class="card-header lead-label">Lead 1</div>
                                    <?php endif; ?>

                                    <div class="card-body">
                                        <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Source <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'source_id[]' : 'source_id'); ?>" class="form-select select2" required>
                                            <option value="" disabled selected>Pilih</option>
                                            <?php
                                                $filter = ['Canvas', 'Visit', 'Expo'];
                                                $isNew = empty($form_data->source_id);
                                            ?>

                                        <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($isNew ? in_array($source->name, $filter) : true): ?>
                                                <option value="<?php echo e($source->id); ?>"
                                                    <?php echo e(old('source_id', $form_data->source_id) == $source->id ? 'selected' : ''); ?>>
                                                    <?php echo e($source->name); ?>

                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Company <i class="required">*</i></label>
                                            <input type="text" name="<?php echo e($isCreate ? 'company[]' : 'company'); ?>" placeholder="Nama Perusahaan" class="form-control"
                                                value="<?php echo e(old('company', $form_data->company)); ?>" required>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Customer Type <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'customer_type[]' : 'customer_type'); ?>" class="form-select select2" required>
                                                <option value="" disabled selected>Pilih</option>
                                                <?php $__currentLoopData = $customerTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($type->name); ?>" <?php echo e(old('customer_type', $form_data->customer_type) == $type->name ? 'selected' : ''); ?>><?php echo e($type->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>                                        

                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Transaction Type <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'segment_id[]' : 'segment_id'); ?>" class="form-select select2" required>
                                            <option value="" disabled selected>Pilih</option>
                                            <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($segment->id); ?>"
                                                    <?php echo e(old('segment_id', $form_data->segment_id) == $segment->id ? 'selected' : ''); ?>>
                                                    <?php echo e($segment->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        
                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">City <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'region_id[]' : 'region_id'); ?>" class="form-select select2 region-select">
                                                <option value="" disabled <?php echo e(old('region_id', $form_data->region_id)===null ? 'selected' : ''); ?>>Pilih</option>
                                                <option value="ALL" <?php echo e(old('region_id', $form_data->region_id)==='ALL' ? 'selected' : ''); ?>>
                                                    All Regions (will show in all regions)
                                                </option>
                                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option 
                                                    value="<?php echo e($region->id); ?>" 
                                                    data-branch="<?php echo e($region->branch_id); ?>"
                                                    <?php echo e(old('region_id', $form_data->region_id)==$region->id ? 'selected' : ''); ?>

                                                    >
                                                    <?php echo e($region->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <input type="hidden" 
                                                name="<?php echo e($isCreate ? 'branch_id[]' : 'branch_id'); ?>" 
                                                class="branch-id-field" 
                                                value="<?php echo e(old('branch_id', $form_data->branch_id)); ?>">
                                        </div>

                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Province <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'province[]' : 'province'); ?>" class="form-select select2 province-select">
                                            <option value="" selected>Pilih</option>
                                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($prov); ?>"
                                                    <?php echo e(old('province', $form_data->province) == $prov ? 'selected' : ''); ?>>
                                                    <?php echo e($prov); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Industry <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'industry_id[]' : 'industry_id'); ?>" class="form-select select2 industry-select" required>
                                                <option value="" disabled selected>Pilih</option>
                                                <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($industry->id); ?>" <?php echo e(old('industry_id', $form_data->industry_id ?? ($form_data->other_industry ? 'other' : null)) == $industry->id ? 'selected' : ''); ?>><?php echo e($industry->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <option value="other" <?php echo e(old('industry_id', $form_data->industry_id ?? ($form_data->other_industry ? 'other' : null)) === 'other' ? 'selected' : ''); ?>>Lainnya</option>
                                            </select>
                                            <input type="text" name="<?php echo e($isCreate ? 'other_industry[]' : 'other_industry'); ?>" class="form-control mt-2 industry-other d-none" placeholder="Isi industri" value="<?php echo e(old('other_industry', $form_data->other_industry)); ?>" />
                                        </div>

                                        <?php
                                            $defaultName = old('name', $form_data->name);
                                            $defaultTitle = old('title');
                                            if (! $isCreate && empty($defaultTitle)) {
                                                if (str_starts_with($defaultName, 'Mr ')) {
                                                    $defaultTitle = 'Mr';
                                                    $defaultName = substr($defaultName, 3);
                                                } elseif (str_starts_with($defaultName, 'Mrs ')) {
                                                    $defaultTitle = 'Mrs';
                                                    $defaultName = substr($defaultName, 4);
                                                }
                                            }
                                        ?>
                                        <div class="col-md-1 mb-3">
                                            <label class="form-label">Title <i class="required">*</i></label>
                                            <br>
                                            <select name="<?php echo e($isCreate ? 'title[]' : 'title'); ?>" class="form-select" required>
                                                <option value="Mr" <?php echo e($defaultTitle === 'Mr' ? 'selected' : ''); ?>>Mr</option>
                                                <option value="Mrs" <?php echo e($defaultTitle === 'Mrs' ? 'selected' : ''); ?>>Mrs</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <label class="form-label">Name <i class="required">*</i></label>
                                            <input type="text" name="<?php echo e($isCreate ? 'name[]' : 'name'); ?>" placeholder="Nama Lengkap" class="form-control"
                                                value="<?php echo e($defaultName); ?>" required>
                                        </div>

                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Jabatan <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'jabatan_id[]' : 'jabatan_id'); ?>" class="form-select select2" required>
                                                <option value="" disabled selected>Pilih</option>
                                                <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($jabatan->id); ?>" <?php echo e(old('jabatan_id', $form_data->jabatan_id) == $jabatan->id ? 'selected' : ''); ?>><?php echo e($jabatan->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col-md-2 mb-3">
                                            <label class="form-label">Phone <i class="required">*</i></label>
                                            <input type="text" name="<?php echo e($isCreate ? 'phone[]' : 'phone'); ?>" placeholder="0812xxxxxxx" class="form-control"
                                                value="<?php echo e(old('phone', $form_data->phone)); ?>" required>
                                        </div>                                                                                

                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Email <i class="required">*</i></label>
                                            <input type="email" name="<?php echo e($isCreate ? 'email[]' : 'email'); ?>" placeholder="email@domain.com" class="form-control"
                                                value="<?php echo e(old('email', $form_data->email)); ?>" required>
                                        </div>

                                        <div class="pic-extensions col-12">
                                            <?php $__currentLoopData = $form_data->picExtensions ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row pic-entry">
                                                    <div class="col-md-1 mb-3">
                                                        <select class="form-select" data-field="title" required>
                                                            <option value="Mr" <?php echo e($pic->title === 'Mr' ? 'selected' : ''); ?>>Mr</option>
                                                            <option value="Mrs" <?php echo e($pic->title === 'Mrs' ? 'selected' : ''); ?>>Mrs</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <input type="text" class="form-control" data-field="nama" value="<?php echo e($pic->nama); ?>" placeholder="Nama Lengkap" required>
                                                    </div>
                                                    <div class="col-md-2 mb-3">
                                                        <select class="form-select select2" data-field="jabatan_id" required>
                                                            <option value="" disabled <?php echo e(empty($pic->jabatan_id) ? 'selected' : ''); ?>>Pilih</option>
                                                            <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($jabatan->id); ?>" <?php echo e($pic->jabatan_id == $jabatan->id ? 'selected' : ''); ?>><?php echo e($jabatan->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-2 mb-3">
                                                        <input type="text" class="form-control" data-field="phone" value="<?php echo e($pic->phone); ?>" placeholder="0812xxxxxxx" required>
                                                    </div>
                                                    <div class="col-md-3 mb-3">
                                                        <input type="email" class="form-control" data-field="email" value="<?php echo e($pic->email); ?>" placeholder="email@domain.com" required>
                                                    </div>
                                                    <div class="col-md-1 mb-3 d-flex align-items-end">
                                                        <button type="button" class="btn btn-outline-danger remove-pic">&times;</button>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <button type="button" class="btn btn-sm btn-outline-primary add-pic">
                                                <i class="bi bi-person-plus me-1"></i> Add PIC
                                            </button>
                                        </div>
                                
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Product <?php if($isCreate): ?><i class="required">*</i><?php endif; ?></label>
                                            <select name="<?php echo e($isCreate ? 'product_id[]' : 'product_id'); ?>" class="form-select select2" <?php if($isCreate): ?> required <?php endif; ?>>
                                                <option value="" disabled selected>Pilih</option>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($p->id); ?>" <?php echo e(old('product_id', $form_data->product_id) == $p->id ? 'selected' : ''); ?>><?php echo e($p->name); ?> (<?php echo e($p->sku); ?>)</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Needs <i class="required">*</i></label>
                                            <select name="<?php echo e($isCreate ? 'needs[]' : 'needs'); ?>" class="form-select select2" required>
                                                <option value="" disabled selected>Pilih</option>
                                                <?php
                                                    $needsOptions = [
                                                        'Tube Ice ( Mesin Es Kristal Tabung )',
                                                        'Cube Ice ( Mesin Es Kristal Kubus )',
                                                        'Block Ice ( Mesin Es Balok )',
                                                        'Flake ice ( Mesin Es Pecah )',
                                                        'Slurry Ice ( Es Bubur halus )',
                                                        'Flake Ice ( Es Serpih )',
                                                        'Cold Room ( Ruang Pendingin )',
                                                        'Other ( Keperluan Kustom )',
                                                    ];
                                                    $selectedNeed = old('needs', $form_data->needs);
                                                ?>
                                                <?php $__currentLoopData = $needsOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $need): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($need); ?>" <?php echo e($selectedNeed == $need ? 'selected' : ''); ?>><?php echo e($need); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label class="form-label">Tonase</label>
                                            <input type="number" step="0.01" name="<?php echo e($isCreate ? 'tonase[]' : 'tonase'); ?>" class="form-control" value="<?php echo e(old('tonase', $form_data->tonase)); ?>" placeholder="0.00">
                                        </div>

                                        <?php if($isCreate): ?>
                                            <div class="col-12 text-end mt-0">
                                                <button type="button" class="btn btn-sm btn-outline-danger remove-lead d-none">
                                                    <i class="bi bi-trash me-1"></i> Remove Lead
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            </div>

                            <?php if($isCreate): ?>
                                <div class="text-end mb-3">
                                    <button type="button" id="add-lead" class="btn btn-outline-primary">
                                        <i class="bi bi-plus-circle me-1"></i> Add Lead
                                    </button>
                                </div>
                            <?php endif; ?>

                            <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                                <?php echo $__env->make('partials.common.save-btn-form', ['backUrl' => 'back'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php if(!empty($form_data->id)): ?>
            
            <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-4">
                    <div class="card-header"><strong>Meeting</strong></div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <tr>
                                <th>Schedule</th>
                                <td>
                                    <?php echo e($meeting->scheduled_start_at ? date('d M Y H:i', strtotime($meeting->scheduled_start_at)) : ''); ?>

                                    -
                                    <?php echo e($meeting->scheduled_end_at ? date('d M Y H:i', strtotime($meeting->scheduled_end_at)) : ''); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>Type</th>
                                <td><?php echo e($meeting->is_online ? 'Online' : 'Offline'); ?></td>
                            </tr>
                            <?php if($meeting->is_online): ?>
                                <tr>
                                    <th>URL</th>
                                    <td><?php echo e($meeting->online_url); ?></td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <th>Location</th>
                                    <td><?php echo e(trim(($meeting->city ?? '') . ' ' . ($meeting->address ?? ''))); ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <th>Result</th>
                                <td><?php echo e($meeting->result ?? '-'); ?></td>
                            </tr>
                            <tr>
                                <th>Summary</th>
                                <td><?php echo e($meeting->summary ?? '-'); ?></td>
                            </tr>
                            <?php if($meeting->attachment): ?>
                                <tr>
                                    <th>Attachment</th>
                                    <td>
                                        <a href="<?php echo e(route('attachments.download', $meeting->attachment_id)); ?>"
                                            class="btn btn-sm btn-outline-secondary">Download</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($quotation): ?>
                <div class="card mb-4">
                    <div class="card-header"><strong>Quotation</strong></div>
                    <div class="card-body">
                        <?php
                            $latestReview = $quotation->reviews->sortByDesc('decided_at')->first();
                        ?>
                        <?php if($latestReview): ?>
                            <div class="alert alert-<?php echo e($latestReview->decision === 'reject' ? 'danger' : 'success'); ?>">
                                Quotation <?php echo e($latestReview->decision === 'reject' ? 'rejected' : 'approved'); ?> by
                                <b><?php echo e($latestReview->reviewer->name ?? $latestReview->role); ?></b>
                                on <?php echo e($latestReview->decided_at ? \Carbon\Carbon::parse($latestReview->decided_at)->format('d M Y') : ''); ?><br>
                                <strong>Notes:</strong> <?php echo e($latestReview->notes); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-sm">
                            <tr>
                                <th>No</th>
                                <td><?php echo e($quotation->quotation_no); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td>
                                    <?php
                                        $statusClass =
                                            [
                                                'draft' => 'secondary',
                                                'review' => 'warning',
                                                'published' => 'success',
                                                'rejected' => 'danger',
                                            ][$quotation->status] ?? 'light';
                                    ?>
                                    <span class="badge bg-<?php echo e($statusClass); ?>"><?php echo e(ucfirst($quotation->status)); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th>Grand Total</th>
                                <td>Rp<?php echo e(number_format($quotation->grand_total, 0, ',', '.')); ?></td>
                            </tr>
                            <tr>
                                <th>Expiry Date</th>
                                <td><?php echo e($quotation->expiry_date ? date('d M Y', strtotime($quotation->expiry_date)) : '-'); ?>

                                </td>
                            </tr>
                        </table>
                        <a href="<?php echo e(route('quotations.download', $quotation->id)); ?>"
                            class="btn btn-outline-secondary mb-3">
                            <i class="bi bi-download"></i> Download Quotation
                        </a>

                        <?php if($quotation->items->count()): ?>
                            <h6 class="mt-4">Items</h6>
                            <table class="table table-bordered table-sm">
                                <thead class="table-light">
                                    <tr>
                                        <th>Description</th>
                                        <th>Qty</th>
                                        <th>Unit Price</th>
                                        <th>Disc %</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $quotation->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->description); ?></td>
                                            <td><?php echo e($item->qty); ?></td>
                                            <td>Rp<?php echo e(number_format($item->unit_price, 0, ',', '.')); ?></td>
                                            <td><?php echo e($item->discount_pct); ?></td>
                                            <td>Rp<?php echo e(number_format($item->line_total, 0, ',', '.')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="4" class="text-end">Sub Total</th>
                                        <th class="text-end">Rp<?php echo e(number_format($quotation->subtotal, 0, ',', '.')); ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="4" class="text-end">Tax (<?php echo e($quotation->tax_pct); ?>%)</th>
                                        <th class="text-end">Rp<?php echo e(number_format($quotation->tax_total, 0, ',', '.')); ?></th>
                                    </tr>
                                    <?php if(!empty($quotation->discount)): ?>
                                        <tr>
                                            <th colspan="4" class="text-end">Discount</th>
                                            <th class="text-end text-danger">-
                                                Rp<?php echo e(number_format($quotation->discount, 0, ',', '.')); ?></th>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <th colspan="4" class="text-end">Grand Total</th>
                                        <th class="text-end fw-bold">
                                            Rp<?php echo e(number_format($quotation->grand_total, 0, ',', '.')); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php endif; ?>

                        <?php if($quotation->proformas->count()): ?>
                            <h6 class="mt-4">Proformas</h6>
                            <table class="table table-bordered table-sm">
                                <thead class="table-light">
                                    <tr>
                                        <th>Term</th>
                                        <th>No</th>
                                        <th>Status</th>
                                        <th>Issued</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $quotation->proformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($pf->term_no ?? 'Booking Fee'); ?></td>
                                            <td><?php echo e($pf->proforma_no ?? '-'); ?></td>
                                            <td><?php echo e(ucfirst($pf->status)); ?></td>
                                            <td><?php echo e($pf->issued_at ? date('d M Y', strtotime($pf->issued_at)) : '-'); ?></td>
                                            <td>
                                                Rp<?php echo e(number_format($pf->amount, 0, ',', '.')); ?>

                                                <?php if($pf->paymentConfirmation): ?>
                                                    <?php $fr = $pf->paymentConfirmation->financeRequest; ?>
                                                    <?php if($fr && in_array($fr->status, ['approved','rejected'])): ?>
                                                        <div class="small text-<?php echo e($fr->status === 'approved' ? 'success' : 'danger'); ?> mt-1">
                                                            <?php echo e(ucfirst($fr->status)); ?>: <?php echo e($fr->notes); ?>

                                                        </div>
                                                    <?php elseif($fr): ?>
                                                        <div class="small text-warning mt-1">Awaiting Finance</div>
                                                    <?php endif; ?>
                                                    <?php if($fr && $fr->status !== 'rejected'): ?>
                                                        <div class="small text-success mt-1">
                                                            Paid at:
                                                            <?php echo e($pf->paymentConfirmation->paid_at->format('d M Y')); ?><br>
                                                            Confirmed by:
                                                            <?php echo e($pf->paymentConfirmation->confirmedBy?->name ?? '-'); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($pf->attachment_id): ?>
                                                    <a href="<?php echo e(route('attachments.download', $pf->attachment_id)); ?>"
                                                        class="btn btn-sm btn-outline-secondary">
                                                        <i class="bi bi-download"></i> Proforma
                                                    </a>
                                                <?php endif; ?>

                                                <?php if($pf->invoice && $pf->invoice->attachment_id): ?>
                                                    <a href="<?php echo e(route('attachments.download', $pf->invoice->attachment_id)); ?>"
                                                        class="btn btn-sm btn-outline-secondary ms-1">
                                                        <i class="bi bi-download"></i> Invoice
                                                    </a>
                                                <?php endif; ?>

                                                <?php if($pf->status === 'confirmed'): ?>
                                                    <?php $fr = $pf->paymentConfirmation?->financeRequest; ?>
                                                    <?php if(!$pf->paymentConfirmation): ?>
                                                        <a href="<?php echo e(route('payment-confirmation.terms.payment.confirm.form', [$quotation->lead_id, $pf->term_no ?? 'bf'])); ?>"
                                                            class="btn btn-sm btn-outline-primary ml-1">
                                                            <i class="bi bi-cash-coin"></i> Confirm Payment
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('payment-confirmation.terms.payment.confirm.form', [$quotation->lead_id, $pf->term_no ?? 'bf'])); ?>"
                                                            class="btn btn-sm <?php echo e($fr && $fr->status === 'rejected' ? 'btn-outline-danger' : 'btn-outline-success'); ?> ml-1">
                                                            <i
                                                                class="bi <?php echo e($fr && $fr->status === 'rejected' ? 'bi-pencil-square' : 'bi-eye'); ?>"></i>
                                                            <?php echo e($fr && $fr->status === 'rejected' ? 'Edit Payment' : 'View Payment'); ?>

                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            
            <?php if($order): ?>
                <div class="card mb-4">
                    <div class="card-header"><strong>Order</strong></div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <tr>
                                <th>Order No</th>
                                <td><?php echo e($order->order_no); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e($order->order_status); ?></td>
                            </tr>
                            <tr>
                                <th>Total Billing</th>
                                <td>Rp<?php echo e(number_format($order->total_billing, 0, ',', '.')); ?></td>
                            </tr>
                        </table>

                        <?php if($order->orderItems->count()): ?>
                            <h6 class="mt-4">Items</h6>
                            <table class="table table-bordered table-sm">
                                <thead class="table-light">
                                    <tr>
                                        <th>Description</th>
                                        <th>Qty</th>
                                        <th>Unit Price</th>
                                        <th>Disc %</th>
                                        <th>Tax %</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->description); ?></td>
                                            <td><?php echo e($item->qty); ?></td>
                                            <td>Rp<?php echo e(number_format($item->unit_price, 0, ',', '.')); ?></td>
                                            <td><?php echo e($item->discount_pct); ?></td>
                                            <td><?php echo e($item->tax_pct); ?></td>
                                            <td>Rp<?php echo e(number_format($item->line_total, 0, ',', '.')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
    $(function () {
    /* -----------------------------------------------------------
    * helper: initialise select2 on the given jQuery collection
    * --------------------------------------------------------- */
    function initSelect2($elements) {
        $elements.each(function () {
        const $sel = $(this);

        // if this <select> already has Select2, leave it alone
        if ($sel.data('select2')) return;

        $sel.select2({ width: '100%' });
        });
    }

    function styleDisabledProvince($target) {
        $target.each(function () {
            const $select = $(this);
            const $select2Container = $select.next('.select2-container');

            $select2Container.find('.select2-selection').css({
                'background-color': '#e9ecef',
                'color': '#6c757d',
                'pointer-events': 'none',
                'border-color': '#ced4da',
                'cursor': 'not-allowed'
            });
        });
    }

    /* -----------------------------------------------------------
    * helper: renumber the “Lead n” labels
    * --------------------------------------------------------- */
    function updateLeadLabels() {
        $('#lead-entries .lead-entry').each(function (i) {
        $(this).find('.lead-label').text('Lead ' + (i + 1));
        });
        updateLeadPicNames();
    }

    function updateLeadPicNames() {
        $('#lead-entries .lead-entry').each(function(i){
            $(this).attr('data-index', i);
            $(this).find('.pic-entry').each(function(){
                $(this).find('[data-field]').each(function(){
                    const field = $(this).data('field');
                    $(this).attr('name', `pic_extensions[${i}][${field}][]`);
                });
            });
        });
    }

    /* -----------------------------------------------------------
    * PAGE-LOAD: turn the first row into Select2 widgets
    * --------------------------------------------------------- */
    initSelect2($('#lead-entries').find('select.select2'));
    styleDisabledProvince($('#lead-entries').find('.province-select'));
    updateLeadLabels();
    updateLeadPicNames();

    const regionProvinces = <?php echo json_encode($regions->pluck('province.name', 'id'), 512) ?>;
    $('#lead-entries .province-select').on('select2:opening', e => e.preventDefault());
    $('#lead-entries .region-select').each(function(){
        setProvince($(this));
    });

    function toggleIndustryOther($select) {
        const $entry = $select.closest('.lead-entry');
        const $other = $entry.find('.industry-other');
        if ($select.val() === 'other') {
            $other.removeClass('d-none').prop('required', true);
        } else {
            $other.addClass('d-none').prop('required', false).val('');
        }
    }

    $('#lead-entries .industry-select').each(function(){
        toggleIndustryOther($(this));
    });

    /* -----------------------------------------------------------
    * PIC extension add/remove
    * --------------------------------------------------------- */
    const jabatanOptions = <?php echo json_encode($jabatans->pluck('name', 'id'), 512) ?>;

    function jabatanSelectHtml() {
        let opts = '<option value="" disabled selected>Pilih</option>';
        Object.entries(jabatanOptions).forEach(([id,name]) => {
            opts += `<option value="${id}">${name}</option>`;
        });
        return `<select class="form-select select2" data-field="jabatan_id" required>${opts}</select>`;
    }

    function picEntryHtml() {
        return `
        <div class="row pic-entry">
            <div class="col-md-1 mb-3">
                <select class="form-select" data-field="title" required>
                    <option value="Mr">Mr</option>
                    <option value="Mrs">Mrs</option>
                </select>
            </div>
            <div class="col-md-3 mb-3">
                <input type="text" class="form-control" data-field="nama" placeholder="Nama Lengkap" required>
            </div>
            <div class="col-md-2 mb-3 jabatan-field">
                ${jabatanSelectHtml()}
            </div>
            <div class="col-md-2 mb-3">
                <input type="text" class="form-control" data-field="phone" placeholder="0812xxxxxxx" required>
            </div>
            <div class="col-md-3 mb-3">
                <input type="email" class="form-control" data-field="email" placeholder="email@domain.com" required>
            </div>
            <div class="col-md-1 mb-3 d-flex align-items-end">
                <button type="button" class="btn btn-outline-danger remove-pic">&times;</button>
            </div>
        </div>`;
    }

    $(document).on('click', '.add-pic', function(){
        const $entry = $(this).closest('.lead-entry');
        const $html = $(picEntryHtml());
        $entry.find('.pic-extensions').append($html);
        initSelect2($html.find('select.select2'));
        updateLeadPicNames();
    });

    $(document).on('click', '.remove-pic', function(){
        $(this).closest('.pic-entry').remove();
        updateLeadPicNames();
    });

    /* -----------------------------------------------------------
    * ADD lead
    * --------------------------------------------------------- */
    $('#add-lead').on('click', function () {
        const $template = $('#lead-entries .lead-entry:first');
        const $clone    = $template.clone(false, false);   // Shallow-clone, no data/events

        /* ---- strip Select2 from the clone (important!) ---- */
        $clone.find('select.select2').each(function () {
        const $sel = $(this);

        // remove any duplicated Select2 container that came across in the clone
        $sel.siblings('.select2-container').remove();

        // remove Select2‐related markup / classes / data so it’s a brand-new <select>
        $sel.removeAttr('data-select2-id')
            .removeClass('select2-hidden-accessible')
            .removeData('select2')
            .show();

        // cloned <option> tags keep their Select2 IDs and selections
        $sel.find('option')
            .removeAttr('data-select2-id')
            .prop('selected', false)
            .removeAttr('selected');
        });

        /* ---- clear field values ---- */
        $clone.find('input').val('');
        // ensure select boxes start on their placeholder
        $clone.find('select').each(function () {
            const $select = $(this);
            $select.val(''); // reset to empty

            // Jika ada option pertama yang kosong (""), pastikan tidak disabled
            const $firstOption = $select.find('option:first-child');
            if ($firstOption.val() === '' && $firstOption.prop('disabled')) {
                $firstOption.prop('disabled', false);
            }
        });
        /* ---- show remove button ---- */
        $clone.find('.remove-lead').removeClass('d-none');

        $clone.find('.pic-extensions').empty();

        /* ---- append clone & init its Select2s only ---- */
        $('#lead-entries').append($clone);
        initSelect2($clone.find('select.select2'));
        styleDisabledProvince($clone.find('.province-select'));

        $clone.find('.province-select').on('select2:opening', e => e.preventDefault());
        setProvince($clone.find('.region-select'));
        toggleIndustryOther($clone.find('.industry-select'));
        updateLeadLabels();
    });

    /* -----------------------------------------------------------
    * REMOVE lead
    * --------------------------------------------------------- */
    $(document).on('click', '.remove-lead', function () {
        $(this).closest('.lead-entry').remove();
        updateLeadLabels();
    });

    /* -----------------------------------------------------------
    * keep hidden branch_id in sync
    * --------------------------------------------------------- */
    function setProvince($regionSelect) {
        const regionId = $regionSelect.val();
        const $entry = $regionSelect.closest('.lead-entry');
        const $provinceSelect = $entry.find('.province-select');

        if (regionId === 'ALL') {
            $provinceSelect.val('').trigger('change.select2');
            $provinceSelect.prop('required', false);
        } else {
            const province = regionProvinces[regionId] || '';
            $provinceSelect.val(province).trigger('change.select2');
            $provinceSelect.prop('required', true);
        }
    }

    $(document).on('select2:opening', '.province-select', function (e) {
        e.preventDefault();
    });

    $(document).on('change', '.region-select', function () {
        const branch = $(this).find('option:selected').data('branch');
        $(this).closest('.lead-entry').find('.branch-id-field').val(branch);
        setProvince($(this));
    });

    $(document).on('change', '.industry-select', function () {
        toggleIndustryOther($(this));
    });

    /* -----------------------------------------------------------
    * Claim-lead button
    * --------------------------------------------------------- */
    $('#btnClaim').on('click', function () {
        const url = $(this).data('url');

        Swal.fire({
        title: 'Are you sure?',
        text: 'You are about to claim this lead.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, claim it!',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#aaa'
        }).then(res => {
        if (!res.isConfirmed) return;

        $.post(url, { _token: '<?php echo e(csrf_token()); ?>' })
            .done(() => {
            notif('Lead claimed successfully');
            location.href = '<?php echo e(route('leads.my')); ?>';
            })
            .fail(xhr => {
            notif(xhr.responseJSON?.message || 'Failed to claim lead', 'error');
            });
        });
    });
    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /usr/local/var/www/daxtro2-main/resources/views/pages/leads/form.blade.php ENDPATH**/ ?>