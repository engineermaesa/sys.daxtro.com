<?php

return [
    App\Providers\AppServiceProvider::class,
    Webklex\PDFMerger\Providers\PDFMergerServiceProvider::class,
];
