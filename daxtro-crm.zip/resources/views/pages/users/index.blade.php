@extends('layouts.app')
@section('content')
<h1 class="h3 mb-4 text-gray-800">Manage Users</h1>
@endsection
